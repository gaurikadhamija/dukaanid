(function () {
  'use strict';

  const imgKitchen = './assets/images/biz_meena_kitchen_1794569056635.jpg';
  const imgTailor = './assets/images/biz_aditi_tailor_1794569057006.jpg';
  const imgElectrical = './assets/images/biz_sharma_electrical_1794569059055.jpg';
  const imgArtisan = './assets/images/biz_artisan_corner_1794569073580.jpg';
  const imgBeauty = './assets/images/biz_glow_beauty_1794569058321.jpg';
  const imgPlumber = './assets/images/biz_rajesh_plumbing_1794569059347.jpg';

  const STORAGE_KEY = 'dukaanid_demo_state_v1';

/* ==========================================================================
   Translations (English & Hindi)
   ========================================================================== */
const I18N = {
  en: {
    tagline: 'Har Skill Ko Ek Pehchaan.',
    nav_home: 'Home',
    nav_explore: 'Explore Businesses',
    nav_how: 'How It Works',
    nav_agents: 'AI Agents',
    nav_business: 'For Businesses',
    nav_about: 'About Us',
    nav_login: 'Login',
    nav_start: 'Get Started',
    hero_badge: 'AI-POWERED DIGITAL BUSINESS IDENTITY',
    hero_title: 'Your Skills Deserve a Digital Identity.',
    hero_desc:
      "From local neighbourhood businesses to digital marketplaces, DukaanID helps India's skilled workforce get discovered, build trust, manage customers and unlock financial opportunities.",
    hero_cta_primary: 'Create Your DukaanID',
    hero_cta_secondary: 'Explore How It Works',
    trust_1: 'Digital Business Identity',
    trust_2: 'AI-Powered Assistance',
    trust_3: 'Credit-Ready Reputation',
    stat_1: 'Informal workforce in India',
    stat_2: 'Micro & small business establishments',
    stat_3: 'Illustrative annual market reach',
    stat_4: 'Businesses seeking digital visibility',
    problem_title: "India's Most Skilled Workforce. One of Its Least Digitised.",
    agents_title: 'Meet Your AI Business Team.',
    explore_title: 'Discover Skills. Support Local Businesses.'
  },
  hi: {
    tagline: 'हर स्किल को एक पहचान।',
    nav_home: 'होम',
    nav_explore: 'व्यवसाय खोजें',
    nav_how: 'कैसे काम करता है',
    nav_agents: 'AI एजेंट्स',
    nav_business: 'व्यवसायों के लिए',
    nav_about: 'हमारे बारे में',
    nav_login: 'लॉगिन',
    nav_start: 'शुरू करें',
    hero_badge: 'AI-संचालित डिजिटल बिज़नेस पहचान',
    hero_title: 'आपके हुनर को मिलनी चाहिए एक डिजिटल पहचान।',
    hero_desc:
      'स्थानीय मोहल्ले के काम से लेकर डिजिटल बाज़ार तक, DukaanID भारत के कुशल कामगारों को ग्राहकों तक पहुँचने, भरोसा बनाने, काम संभालने और वित्तीय अवसर पाने में मदद करता है।',
    hero_cta_primary: 'अपना DukaanID बनाएँ',
    hero_cta_secondary: 'जानें यह कैसे काम करता है',
    trust_1: 'डिजिटल बिज़नेस पहचान',
    trust_2: 'AI सहायक टीम',
    trust_3: 'क्रेडिट-रेडी प्रतिष्ठा',
    stat_1: 'भारत में असंगठित कार्यबल',
    stat_2: 'सूक्ष्म और छोटे व्यवसाय',
    stat_3: 'अनुमानित वार्षिक बाज़ार पहुँच',
    stat_4: 'डिजिटल पहचान चाहने वाले व्यवसाय',
    problem_title: 'भारत का सबसे कुशल कार्यबल। लेकिन डिजिटल रूप से सबसे पीछे।',
    agents_title: 'अपनी AI बिज़नेस टीम से मिलें।',
    explore_title: 'हुनर खोजें। स्थानीय व्यवसायों का साथ दें।'
  }
};

/* ==========================================================================
   Default Seed Data (Realistic Indian Micro-Businesses)
   ========================================================================== */
function getInitialState() {
  return {
    lang: 'en',
    activeView: 'landing',
    activeStoreId: 'aditi-tailoring',
    activeDashTab: 'overview',
    activeAgentTab: 'onboarding',
    activityLog: [
      { id: 'act-1', title: 'Meena’s storefront is live', detail: 'Onboarding Agent created a shareable business profile.', time: 'Today · 9:15 AM', type: 'Onboarding' },
      { id: 'act-2', title: 'New customer enquiry received', detail: 'Customer Agent prepared a draft response for review.', time: 'Today · 10:05 AM', type: 'Customer' },
      { id: 'act-3', title: 'Credit passport is ready to preview', detail: 'Credit-Readiness Agent summarised the available demo records.', time: 'Today · 10:30 AM', type: 'Credit' }
    ],
    exploreFilter: {
      search: '',
      location: 'all',
      category: 'All',
      sort: 'rating'
    },
    businesses: [
      {
        id: 'aditi-tailoring',
        name: 'Aditi Tailoring Studio',
        owner: 'Aditi Verma',
        category: 'Tailoring',
        location: 'Delhi',
        area: 'Lajpat Nagar II, New Delhi',
        phone: '+91 98114 27630',
        distanceKm: 1.2,
        rating: 4.9,
        popularity: 98,
        verified: true,
        completedJobs: 148,
        repeatRate: 68,
        startingPrice: 150,
        hours: '10:00 AM – 8:00 PM (Mon–Sat)',
        availability: 'Slots open tomorrow from 11:00 AM',
        image: imgTailor,
        description:
          'Neighbourhood boutique tailoring studio specialising in bridal blouse stitching, saree fall-pico, suit fitting, and same-day trouser alterations.',
        services: [
          { name: 'Designer Blouse Stitching', duration: '2–3 days', price: 650 },
          { name: 'Salwar Suit Custom Stitching', duration: '3 days', price: 850 },
          { name: 'Saree Fall & Pico Finishing', duration: 'Same day', price: 180 },
          { name: 'Trouser / Kurti Alteration', duration: '4 hours', price: 150 }
        ],
        reviews: [
          {
            author: 'Priya Sharma',
            rating: 5,
            repeat: true,
            service: 'Tailoring',
            date: '2 days ago',
            text: 'Perfect blouse fitting and delivered right on time before our family wedding.'
          },
          {
            author: 'Neha Kapoor',
            rating: 5,
            repeat: true,
            service: 'Tailoring',
            date: '1 week ago',
            text: 'Very neat stitching and transparent pricing. My regular boutique in Lajpat Nagar.'
          },
          {
            author: 'Ritu Malhotra',
            rating: 4,
            repeat: false,
            service: 'Alteration',
            date: '2 weeks ago',
            text: 'Quick trouser alteration within 3 hours. Courteous and reliable.'
          }
        ]
      },
      {
        id: 'meena-kitchen',
        name: "Meena's Homemade Kitchen",
        owner: 'Meena Devi',
        category: 'Home Food',
        location: 'Delhi',
        area: 'Malviya Nagar, New Delhi',
        phone: '+91 98712 55410',
        distanceKm: 1.8,
        rating: 4.9,
        popularity: 96,
        verified: true,
        completedJobs: 312,
        repeatRate: 76,
        startingPrice: 120,
        hours: '7:30 AM – 9:00 PM (Daily)',
        availability: 'Accepting lunch & dinner tiffin orders',
        image: imgKitchen,
        description:
          'Fresh, hygienic ghar-ka-khana tiffin meals, weekly homestyle dabba subscriptions, and festive thalis prepared daily with cold-pressed mustard oil and whole spices.',
        services: [
          { name: 'Homestyle Veg Thali Tiffin', duration: 'Daily 12:30 PM', price: 120 },
          { name: 'Weekly Office Tiffin (5 Meals)', duration: 'Mon–Fri', price: 550 },
          { name: 'Special Paneer & Dal Makhani Box', duration: '2 hours notice', price: 220 },
          { name: 'Small Family Gathering Catering (10 pax)', duration: '1 day notice', price: 1850 }
        ],
        reviews: [
          {
            author: 'Ankit Verma',
            rating: 5,
            repeat: true,
            service: 'Tiffin',
            date: 'Yesterday',
            text: 'Light, zero-excess-oil home meals just like home. Been subscribing for 4 months.'
          },
          {
            author: 'Kavita Nair',
            rating: 5,
            repeat: true,
            service: 'Catering',
            date: '5 days ago',
            text: 'Ordered food for our parents visit and everyone loved the rotis and dal.'
          }
        ]
      },
      {
        id: 'sharma-electrical',
        name: 'Sharma Electrical Services',
        owner: 'Rakesh Sharma',
        category: 'Electrical',
        location: 'Bengaluru',
        area: 'Indiranagar, Bengaluru',
        phone: '+91 99004 38122',
        distanceKm: 0.9,
        rating: 4.8,
        popularity: 92,
        verified: true,
        completedJobs: 214,
        repeatRate: 61,
        startingPrice: 199,
        hours: '8:00 AM – 9:00 PM (Daily)',
        availability: 'Available today after 4:00 PM',
        image: imgElectrical,
        description:
          'Certified residential electrician for MCB board upgrades, inverter setup, geyser thermostat repair, ceiling fan installation, and safety earthing checks.',
        services: [
          { name: 'Geyser Inspection & Thermostat Repair', duration: '45 mins', price: 350 },
          { name: 'Ceiling Fan / Exhaust Installation', duration: '30 mins', price: 249 },
          { name: 'MCB & Switchboard Troubleshooting', duration: '1 hour', price: 199 },
          { name: 'Home Inverter & Battery Wiring', duration: '2 hours', price: 750 }
        ],
        reviews: [
          {
            author: 'Siddharth Rao',
            rating: 5,
            repeat: true,
            service: 'Electrical',
            date: '3 days ago',
            text: 'Arrived on time with proper multimeter diagnostics. Clear invoice provided.'
          }
        ]
      },
      {
        id: 'artisan-corner',
        name: 'The Artisan Corner',
        owner: 'Harish Prajapati',
        category: 'Handicrafts',
        location: 'Jaipur',
        area: 'Bapu Nagar, Jaipur',
        phone: '+91 94140 88219',
        distanceKm: 2.4,
        rating: 4.8,
        popularity: 89,
        verified: true,
        completedJobs: 127,
        repeatRate: 54,
        startingPrice: 250,
        hours: '10:30 AM – 7:30 PM (Tue–Sun)',
        availability: 'Custom gift hampers ready in 2 days',
        image: imgArtisan,
        description:
          'Handcrafted terracotta diyas, carved wooden block-print stamps, handloom table runners, and custom festive corporate gifting direct from Jaipur artisans.',
        services: [
          { name: 'Handcrafted Terracotta Diya Set (12 pcs)', duration: 'Ready to ship', price: 250 },
          { name: 'Carved Sheesham Wood Block Stamp', duration: '2 days', price: 420 },
          { name: 'Festive Brass & Clay Gift Hamper', duration: '3 days', price: 950 }
        ],
        reviews: [
          {
            author: 'Meera Singhania',
            rating: 5,
            repeat: true,
            service: 'Handicrafts',
            date: '1 week ago',
            text: 'Ordered 25 Diwali hampers for our clinic. Packaging and craft quality were superb.'
          }
        ]
      },
      {
        id: 'glow-beauty',
        name: 'Glow Beauty Studio',
        owner: 'Sana Khan',
        category: 'Beauty',
        location: 'Pune',
        area: 'Kothrud, Pune',
        phone: '+91 97652 11904',
        distanceKm: 1.5,
        rating: 4.9,
        popularity: 94,
        verified: true,
        completedJobs: 196,
        repeatRate: 72,
        startingPrice: 299,
        hours: '10:00 AM – 8:30 PM (Tue–Sun)',
        availability: 'Weekend bridal & facial slots open',
        image: imgBeauty,
        description:
          'Hygienic neighbourhood skincare, botanical hair spa, bridal mehndi, and doorstep saree draping services by a certified beautician.',
        services: [
          { name: 'Botanical Cleanup & Glow Facial', duration: '50 mins', price: 599 },
          { name: 'Bridal Saree Draping & Hair Styling', duration: '1.5 hours', price: 1200 },
          { name: 'Natural Henna Mehndi (Both Hands)', duration: '1 hour', price: 450 },
          { name: 'Ayurvedic Hair Spa & Massage', duration: '45 mins', price: 299 }
        ],
        reviews: [
          {
            author: 'Pallavi Joshi',
            rating: 5,
            repeat: true,
            service: 'Beauty',
            date: '4 days ago',
            text: 'Clean studio, gentle products, and fixed rates without pushy upselling.'
          }
        ]
      },
      {
        id: 'rajesh-plumbing',
        name: 'Rajesh Plumbing Services',
        owner: 'Rajesh Yadav',
        category: 'Plumbing',
        location: 'Mumbai',
        area: 'Andheri West, Mumbai',
        phone: '+91 98207 64311',
        distanceKm: 2.1,
        rating: 4.7,
        popularity: 87,
        verified: true,
        completedJobs: 184,
        repeatRate: 58,
        startingPrice: 180,
        hours: '8:30 AM – 8:30 PM (Daily)',
        availability: 'Emergency leak visit within 90 mins',
        image: imgPlumber,
        description:
          'Reliable residential plumbing for tap cartridge replacement, concealed tank repairs, kitchen sink drainage, and bathroom fitting installations.',
        services: [
          { name: 'Tap / Mixer Leakage Repair', duration: '30 mins', price: 180 },
          { name: 'Kitchen Sink & Drain Unclogging', duration: '45 mins', price: 320 },
          { name: 'Washbasin & Jet Spray Installation', duration: '1 hour', price: 450 }
        ],
        reviews: [
          {
            author: 'Devika Kulkarni',
            rating: 5,
            repeat: false,
            service: 'Plumbing',
            date: '6 days ago',
            text: 'Fixed our bathroom mixer cleanly without breaking tiles. Very fair charge.'
          }
        ]
      }
    ],
    workerProfile: {
      id: 'DK-DEL-4821',
      businessName: "Meena's Homemade Kitchen",
      ownerName: 'Meena Devi',
      category: 'Home Food & Tiffin',
      location: 'Malviya Nagar, New Delhi',
      phone: '+91 98712 55410',
      hours: '7:30 AM – 9:00 PM (Mon–Sun)',
      verified: true,
      description:
        'Fresh homestyle veg tiffins, weekly lunch dabbas, and small family catering prepared daily in a clean home kitchen.',
      services: [
        { name: 'Homestyle Veg Thali Tiffin', price: 120 },
        { name: 'Weekly Office Tiffin (5 Meals)', price: 550 },
        { name: 'Special Paneer & Dal Makhani Box', price: 220 }
      ]
    },
    bookings: [
      {
        id: 'BK-904',
        customer: 'Ankit Verma',
        phone: '+91 98101 44219',
        service: 'Weekly Office Tiffin (5 Meals)',
        date: '2026-11-14',
        time: '12:30 PM',
        amount: 550,
        status: 'Pending'
      },
      {
        id: 'BK-903',
        customer: 'Sonal Gupta',
        phone: '+91 98733 19044',
        service: 'Special Paneer & Dal Makhani Box',
        date: '2026-11-14',
        time: '01:15 PM',
        amount: 440,
        status: 'Pending'
      },
      {
        id: 'BK-902',
        customer: 'Kavita Nair',
        phone: '+91 99102 77812',
        service: 'Small Family Gathering Catering (10 pax)',
        date: '2026-11-15',
        time: '07:00 PM',
        amount: 1850,
        status: 'Confirmed'
      },
      {
        id: 'BK-901',
        customer: 'Rohit Malhotra',
        phone: '+91 98118 22310',
        service: 'Homestyle Veg Thali Tiffin',
        date: '2026-11-12',
        time: '12:30 PM',
        amount: 240,
        status: 'Completed'
      },
      {
        id: 'BK-899',
        customer: 'Pooja Sethi',
        phone: '+91 97114 66201',
        service: 'Weekly Office Tiffin (5 Meals)',
        date: '2026-11-10',
        time: '12:00 PM',
        amount: 550,
        status: 'Completed'
      },
      {
        id: 'BK-897',
        customer: 'Deepak Joshi',
        phone: '+91 98991 31208',
        service: 'Homestyle Veg Thali Tiffin',
        date: '2026-11-09',
        time: '01:00 PM',
        amount: 120,
        status: 'Cancelled'
      }
    ],
    customers: [
      { name: 'Ankit Verma', phone: '+91 98101 44219', orders: 14, lastSeen: 'Today', spent: 7450, tag: 'Repeat' },
      { name: 'Kavita Nair', phone: '+91 99102 77812', orders: 8, lastSeen: '2 days ago', spent: 6120, tag: 'Repeat' },
      { name: 'Sonal Gupta', phone: '+91 98733 19044', orders: 5, lastSeen: 'Today', spent: 2680, tag: 'Active' },
      { name: 'Rohit Malhotra', phone: '+91 98118 22310', orders: 11, lastSeen: 'Yesterday', spent: 4320, tag: 'Repeat' },
      { name: 'Pooja Sethi', phone: '+91 97114 66201', orders: 3, lastSeen: '3 weeks ago', spent: 1650, tag: 'Follow-up' }
    ],
    invoices: [
      { id: 'INV-2041', customer: 'Kavita Nair', service: 'Family Catering (10 pax)', date: '13 Nov 2026', amount: 1850, status: 'Pending' },
      { id: 'INV-2040', customer: 'Ankit Verma', service: 'Weekly Office Tiffin', date: '11 Nov 2026', amount: 550, status: 'Paid' },
      { id: 'INV-2039', customer: 'Sonal Gupta', service: 'Special Paneer Box (x2)', date: '10 Nov 2026', amount: 440, status: 'Pending' },
      { id: 'INV-2038', customer: 'Rohit Malhotra', service: 'Monthly Meal Pack', date: '06 Nov 2026', amount: 2400, status: 'Paid' }
    ],
    agentDemo: {
      onboardingTranscript:
        'I am a tailor. I stitch blouses and alter trousers. My shop is in Delhi.',
      customerQuoteStatus: 'awaiting_approval',
      customerQuotePrice: 350,
      operationsTasks: [
        { id: 'op1', label: '3 pending bookings awaiting time confirmation', tag: 'Bookings', done: false },
        { id: 'op2', label: '2 unpaid invoices due from regular customers (₹2,290)', tag: 'Invoices', done: false },
        { id: 'op3', label: '1 low-stock notification: Packaging containers (< 15 left)', tag: 'Inventory', done: false },
        { id: 'op4', label: '4 customer follow-ups due for weekly tiffin renewal', tag: 'Follow-ups', done: false }
      ],
      reputationFilter: 'all',
      creditConsentGranted: false
    },
    onboardingDraft: {
      step: 1,
      name: '',
      phone: '',
      category: 'Tailoring',
      description: '',
      photos: [imgTailor],
      services: [
        { name: 'Custom Stitching', price: 450 },
        { name: 'Quick Alteration', price: 150 }
      ],
      location: 'Delhi',
      hours: '10:00 AM – 8:00 PM (Mon–Sat)',
      createdBusinessId: null
    }
  };
}

let state = loadState();
let overviewChartInstance = null;
let creditChartInstance = null;

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getInitialState();
    const parsed = JSON.parse(raw);
    const base = getInitialState();
    return {
      ...base,
      ...parsed,
      exploreFilter: { ...base.exploreFilter, ...(parsed.exploreFilter || {}) },
      workerProfile: { ...base.workerProfile, ...(parsed.workerProfile || {}) },
      agentDemo: { ...base.agentDemo, ...(parsed.agentDemo || {}) },
      onboardingDraft: { ...base.onboardingDraft, ...(parsed.onboardingDraft || {}) },
      activityLog: parsed.activityLog || base.activityLog
    };
  } catch {
    return getInitialState();
  }
}

function logActivity(title, detail, type = 'Operations') {
  state.activityLog = state.activityLog || [];
  state.activityLog.unshift({
    id: `act-${Date.now()}`,
    title,
    detail,
    type,
    time: new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
  });
  state.activityLog = state.activityLog.slice(0, 12);
  saveState();
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors in private mode
  }
}

/* ==========================================================================
   Utilities (Escaping, QR SVG, Toasts, Lucide Refresh)
   ========================================================================== */
function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function buildStoreUrl(storeId) {
  const safeId = state.businesses.some(b => b.id === storeId) ? storeId : 'meena-kitchen';
  let base;
  if (window.location.protocol === 'file:') base = 'http://localhost:5500/index.html';
  else base = `${window.location.origin}${window.location.pathname}`;
  return `${base}?store=${encodeURIComponent(safeId)}`;
}

function generateQrSvg(seedText, size = 120) {
  // Real, scannable QR image. QR generation requires an internet connection.
  const target = buildStoreUrl(seedText);
  const url = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=8&data=${encodeURIComponent(target)}`;
  return `<img src="${url}" width="${size}" height="${size}" alt="Scannable QR code for ${escapeHtml(target)}" loading="lazy" style="display:block;max-width:100%;height:auto;image-rendering:pixelated" onerror="this.replaceWith(Object.assign(document.createElement('span'),{textContent:'QR unavailable offline'}))" />`;
}

function showToast(message) {
  const stack = document.getElementById('toast-stack');
  if (!stack) return;
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.remove();
  }, 3400);
}

function refreshIcons() {
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }
  bind3DTilt();
}

/* ==========================================================================
   Interactive 3D Perspective Tilt Controller
   ========================================================================== */
function bind3DTilt() {
  if (
    window.matchMedia('(prefers-reduced-motion: reduce)').matches ||
    window.matchMedia('(pointer: coarse)').matches
  ) {
    return;
  }

  const heroStage = document.querySelector('.ecosystem-stage');
  if (heroStage && !heroStage.dataset.tiltBound) {
    heroStage.dataset.tiltBound = '1';
    heroStage.addEventListener('mousemove', (e) => {
      const rect = heroStage.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      heroStage.style.transform = `rotateX(${(-y * 7).toFixed(2)}deg) rotateY(${(x * 8).toFixed(2)}deg)`;
    });
    heroStage.addEventListener('mouseleave', () => {
      heroStage.style.transform = '';
    });
  }

  const cards = document.querySelectorAll(
    '.problem-card, .solution-card, .agent-card, .biz-card, .journey-step, .pricing-card, .kpi-card'
  );
  cards.forEach((card) => {
    if (card.dataset.tiltBound) return;
    card.dataset.tiltBound = '1';
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      card.style.setProperty('--rx', `${(-y * 8).toFixed(2)}deg`);
      card.style.setProperty('--ry', `${(x * 9).toFixed(2)}deg`);
    });
    card.addEventListener('mouseleave', () => {
      card.style.removeProperty('--rx');
      card.style.removeProperty('--ry');
    });
  });
}

/* ==========================================================================
   Modal Controller
   ========================================================================== */
function openModal(title, htmlContent) {
  const modal = document.getElementById('app-modal');
  const titleEl = document.getElementById('modal-title');
  const bodyEl = document.getElementById('modal-body');
  if (!modal || !titleEl || !bodyEl) return;
  titleEl.textContent = title;
  bodyEl.innerHTML = htmlContent;
  modal.classList.add('is-open');
  refreshIcons();
}

function closeModal() {
  const modal = document.getElementById('app-modal');
  if (modal) modal.classList.remove('is-open');
}

/* ==========================================================================
   Language Switching
   ========================================================================== */
function applyLanguage(lang) {
  state.lang = lang === 'hi' ? 'hi' : 'en';
  saveState();
  const dict = I18N[state.lang];
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) el.textContent = dict[key];
  });
  document.querySelectorAll('.lang-btn').forEach((btn) => {
    btn.classList.toggle('is-active', btn.getAttribute('data-lang') === state.lang);
  });
}

/* ==========================================================================
   View Switching & Navigation
   ========================================================================== */
function switchView(viewName, options = {}) {
  state.activeView = viewName;
  if (options.storeId) state.activeStoreId = options.storeId;
  if (options.dashTab) state.activeDashTab = options.dashTab;
  saveState();

  document.querySelectorAll('.app-view').forEach((v) => v.classList.remove('is-active'));
  const target = document.getElementById(`view-${viewName}`);
  if (target) target.classList.add('is-active');

  document.querySelectorAll('.nav-link').forEach((link) => {
    const linkView = link.getAttribute('data-nav-view');
    const linkScroll = link.getAttribute('data-scroll-to');
    if (viewName === 'dashboard') {
      link.classList.toggle('is-active', linkView === 'dashboard');
    } else if (viewName === 'landing') {
      link.classList.toggle(
        'is-active',
        linkView === 'landing' && (!options.scrollTo ? linkScroll === 'hero' : linkScroll === options.scrollTo)
      );
    } else {
      link.classList.remove('is-active');
    }
  });

  // Close mobile drawer if open
  const drawer = document.getElementById('mobile-drawer');
  const ham = document.getElementById('btn-hamburger');
  if (drawer && drawer.classList.contains('is-open')) {
    drawer.classList.remove('is-open');
    if (ham) ham.setAttribute('aria-expanded', 'false');
  }

  if (viewName === 'storefront') renderStorefront();
  if (viewName === 'onboarding') renderOnboarding();
  if (viewName === 'dashboard') renderDashboard();

  if (options.scrollTo) {
    setTimeout(() => {
      const sec = document.getElementById(options.scrollTo);
      if (sec) sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 40);
  } else {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  refreshIcons();
}

/* ==========================================================================
   Landing Page: Agent Cards + 6 Interactive Agent Demos
   ========================================================================== */
const AGENT_DEFINITIONS = [
  {
    id: 'onboarding',
    name: 'Onboarding Agent',
    role: 'Voice-to-Identity Builder',
    icon: 'mic',
    desc: 'Listens to voice notes in local languages, extracts business information and builds a structured profile and service catalogue.',
    does: 'Converts unstructured speech or text into verified business category, services, location and bio.'
  },
  {
    id: 'customer',
    name: 'Customer Agent',
    role: 'Enquiry & Quotation Assistant',
    icon: 'message-square-text',
    desc: 'Handles customer enquiries, checks your calendar availability, drafts clear quotations and prepares booking confirmations.',
    does: 'Always asks for worker approval before sending quotes or confirming appointments.'
  },
  {
    id: 'operations',
    name: 'Operations Agent',
    role: 'Daily Workflow Coordinator',
    icon: 'clipboard-check',
    desc: 'Tracks pending bookings, unpaid invoices, low-stock alerts and customer follow-up reminders from one queue.',
    does: 'Keeps daily shop administration organised without manual spreadsheets.'
  },
  {
    id: 'reputation',
    name: 'Reputation Agent',
    role: 'Portable Trust Ledger',
    icon: 'award',
    desc: 'Maintains verified job completion history, customer reviews, repeat-buyer ratios and word-of-mouth referrals.',
    does: 'Transforms everyday client satisfaction into portable digital proof of quality.'
  },
  {
    id: 'credit',
    name: 'Credit-Readiness Agent',
    role: 'Financial Profile Compiler',
    icon: 'landmark',
    desc: 'Organises monthly inflows, completed transactions and income consistency into a lender-ready summary.',
    does: 'Requires explicit worker consent before sharing any financial profile.'
  },
  {
    id: 'growth',
    name: 'Growth & Market-Access Agent',
    role: 'Pricing & ONDC Discovery',
    icon: 'trending-up',
    desc: 'Identifies popular services, recommends seasonal offers and prepares ONDC-compatible product & service listings.',
    does: 'Helps micro-businesses expand beyond neighbourhood footfall.'
  }
];

function renderAgentCards() {
  const grid = document.getElementById('agents-cards-grid');
  if (!grid) return;

  grid.innerHTML = AGENT_DEFINITIONS.map((agent) => {
    const isSel = state.activeAgentTab === agent.id;
    return `
      <article class="agent-card ${isSel ? 'is-selected' : ''}">
        <div>
          <div class="agent-card__top">
            <div class="agent-card__icon"><i data-lucide="${agent.icon}"></i></div>
            <div>
              <h3 class="agent-card__title">${escapeHtml(agent.name)}</h3>
              <p class="agent-card__role">${escapeHtml(agent.role)}</p>
            </div>
          </div>
          <p class="agent-card__desc">${escapeHtml(agent.desc)}</p>
          <p class="agent-card__does"><strong>What it does:</strong> ${escapeHtml(agent.does)}</p>
        </div>
        <button type="button" class="btn ${isSel ? 'btn--primary' : 'btn--secondary'} btn--sm" data-try-agent="${agent.id}">
          Try Demo <i data-lucide="arrow-right"></i>
        </button>
      </article>
    `;
  }).join('');

  grid.querySelectorAll('[data-try-agent]').forEach((btn) => {
    btn.addEventListener('click', () => {
      selectAgentTab(btn.getAttribute('data-try-agent'), true);
    });
  });
}

function selectAgentTab(agentId, scrollToWorkbench = false) {
  state.activeAgentTab = agentId;
  saveState();

  document.querySelectorAll('[data-agent-tab]').forEach((t) => {
    t.classList.toggle('is-active', t.getAttribute('data-agent-tab') === agentId);
  });
  document.querySelectorAll('[data-agent-select]').forEach((n) => {
    n.classList.toggle('is-active', n.getAttribute('data-agent-select') === agentId);
  });

  renderAgentCards();
  renderAgentWorkbench();

  if (scrollToWorkbench) {
    const wb = document.getElementById('agent-workbench');
    if (wb) wb.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  refreshIcons();
}

function parseOnboardingTranscript(text) {
  const lower = text.toLowerCase();
  let category = 'Local Services';
  let services = ['General Service Consultation', 'Standard Repair / Work'];
  let location = 'New Delhi';
  let bizName = 'Verified Neighbourhood Studio';

  if (lower.includes('tailor') || lower.includes('blouse') || lower.includes('trouser') || lower.includes('सिलाई')) {
    category = 'Tailoring';
    services = ['Blouse stitching', 'Trouser alterations', 'Kurti fitting'];
    bizName = 'Custom Tailoring & Alteration Studio';
  } else if (lower.includes('cook') || lower.includes('tiffin') || lower.includes('food') || lower.includes('dabba')) {
    category = 'Home Food & Tiffin';
    services = ['Daily Veg Tiffin', 'Weekly Lunch Box', 'Home Catering'];
    bizName = 'Homestyle Tiffin Kitchen';
  } else if (lower.includes('electric') || lower.includes('geyser') || lower.includes('fan') || lower.includes('wiring')) {
    category = 'Electrical Services';
    services = ['Geyser & appliance repair', 'Fan & MCB installation', 'Home wiring check'];
    bizName = 'Certified Electrical Services';
  } else if (lower.includes('beauty') || lower.includes('mehndi') || lower.includes('facial')) {
    category = 'Beauty & Wellness';
    services = ['Bridal mehndi', 'Herbal facial', 'Hair spa & draping'];
    bizName = 'Neighbourhood Beauty Studio';
  }

  const cities = ['Delhi', 'Bengaluru', 'Mumbai', 'Pune', 'Jaipur', 'Lucknow'];
  for (const city of cities) {
    if (lower.includes(city.toLowerCase())) {
      location = city;
      break;
    }
  }

  const desc = `Trusted ${category.toLowerCase()} business based in ${location}, offering ${services.join(', ').toLowerCase()} with transparent local pricing.`;
  return { category, services, location, bizName, desc };
}

function renderAgentWorkbench() {
  const container = document.getElementById('agent-demo-content');
  if (!container) return;
  const tab = state.activeAgentTab;

  if (tab === 'onboarding') {
    const transcript = state.agentDemo.onboardingTranscript;
    const parsed = parseOnboardingTranscript(transcript);
    container.innerHTML = `
      <div class="demo-split">
        <div class="demo-panel">
          <h4 class="demo-panel__title">Simulated Voice / Vernacular Input</h4>
          <label for="demo-transcript-input" class="field-label">Select a preset transcript or type your own:</label>
          <textarea id="demo-transcript-input" class="textarea">${escapeHtml(transcript)}</textarea>
          <div class="preset-row">
            <button type="button" class="btn btn--secondary btn--sm" data-preset-transcript="I am a tailor. I stitch blouses and alter trousers. My shop is in Delhi.">Tailor (Delhi)</button>
            <button type="button" class="btn btn--secondary btn--sm" data-preset-transcript="I run a homemade tiffin kitchen in Bengaluru. I prepare fresh veg lunch boxes.">Home Cook (Bengaluru)</button>
            <button type="button" class="btn btn--secondary btn--sm" data-preset-transcript="I am an electrician in Pune doing fan fitting, wiring and geyser repair.">Electrician (Pune)</button>
          </div>
          <button type="button" class="btn btn--primary" id="btn-run-onboarding-extract">
            <i data-lucide="sparkles"></i> Extract Structured Profile
          </button>
        </div>

        <div class="demo-panel">
          <h4 class="demo-panel__title">AI-Extracted DukaanID Profile Preview</h4>
          <div class="kv-list" style="margin-bottom: 18px;">
            <div class="kv-row"><span class="kv-key">Business Type</span><span class="kv-val">${escapeHtml(parsed.category)}</span></div>
            <div class="kv-row"><span class="kv-key">Extracted Services</span><span class="kv-val">${escapeHtml(parsed.services.join(', '))}</span></div>
            <div class="kv-row"><span class="kv-key">Location</span><span class="kv-val">${escapeHtml(parsed.location)}</span></div>
            <div class="kv-row"><span class="kv-key">Suggested Bio</span><span class="kv-val" style="max-width: 65%;">${escapeHtml(parsed.desc)}</span></div>
          </div>
          <div class="notice-box" style="display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap;">
            <div>
              <strong>${escapeHtml(parsed.bizName)}</strong> · ${escapeHtml(parsed.location)}<br/>
              <span style="font-size: 0.78rem; color: var(--indigo-70);">Ready to publish as a QR storefront</span>
            </div>
            <button type="button" class="btn btn--indigo btn--sm" id="btn-demo-launch-onboard">Launch Full Onboarding</button>
          </div>
        </div>
      </div>
    `;

    container.querySelectorAll('[data-preset-transcript]').forEach((b) => {
      b.addEventListener('click', () => {
        state.agentDemo.onboardingTranscript = b.getAttribute('data-preset-transcript');
        saveState();
        renderAgentWorkbench();
        refreshIcons();
      });
    });

    document.getElementById('btn-run-onboarding-extract')?.addEventListener('click', () => {
      const val = document.getElementById('demo-transcript-input')?.value?.trim();
      if (val) state.agentDemo.onboardingTranscript = val;
      saveState();
      renderAgentWorkbench();
      refreshIcons();
      showToast('Onboarding Agent extracted structured business fields.');
    });

    document.getElementById('btn-demo-launch-onboard')?.addEventListener('click', () => {
      switchView('onboarding');
    });
  } else if (tab === 'customer') {
    const quoteStatus = state.agentDemo.customerQuoteStatus;
    const price = state.agentDemo.customerQuotePrice;
    container.innerHTML = `
      <div class="demo-split">
        <div class="demo-panel">
          <h4 class="demo-panel__title">Incoming Customer Enquiry</h4>
          <div style="background: var(--bg-surface); border: 1px solid var(--indigo-12); border-radius: var(--radius-md); padding: 16px; margin-bottom: 16px;">
            <div style="font-size: 0.78rem; color: var(--indigo-55); margin-bottom: 6px;">WhatsApp / Storefront Message · Arjun Mehta</div>
            <p style="font-size: 1rem; font-weight: 600; color: var(--indigo); margin: 0;">"Can you repair my geyser tomorrow?"</p>
          </div>
          <div class="kv-list">
            <div class="kv-row"><span class="kv-key">Service Identified</span><span class="kv-val">Geyser Inspection &amp; Thermostat Repair</span></div>
            <div class="kv-row"><span class="kv-key">Availability Checked</span><span class="kv-val" style="color: var(--success);">Tomorrow · 11:00 AM – 12:30 PM Open</span></div>
            <div class="kv-row"><span class="kv-key">Suggested Quotation</span><span class="kv-val tabular-nums">₹${price} (inspection + labour)</span></div>
            <div class="kv-row"><span class="kv-key">Approval Gate</span><span class="kv-val" style="color: var(--coral);">Worker Approval Required</span></div>
          </div>
        </div>

        <div class="demo-panel">
          <h4 class="demo-panel__title">Worker Decision &amp; Drafted Reply</h4>
          <div style="margin-bottom: 14px;">
            <label for="demo-quote-price" class="field-label">Adjust Suggested Quotation (₹)</label>
            <input type="number" id="demo-quote-price" class="input tabular-nums" value="${price}" min="100" step="50" />
          </div>
          <div class="notice-box" style="margin-bottom: 16px;">
            <strong>Draft Reply to Customer:</strong><br/>
            "Namaste Arjun! Yes, our technician is available tomorrow between 11:00 AM and 12:30 PM for geyser repair. Standard inspection &amp; service charge is ₹${price} (spare parts extra if needed). Reply YES to confirm."
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">
            <button type="button" class="btn btn--success btn--sm" id="btn-quote-approve">Approve &amp; Send Quote</button>
            <button type="button" class="btn btn--secondary btn--sm" id="btn-quote-edit">Update Price</button>
            <button type="button" class="btn btn--danger-outline btn--sm" id="btn-quote-reset">Reset</button>
          </div>
          <p style="margin-top: 12px; font-size: 0.84rem; font-weight: 600; color: ${
            quoteStatus === 'approved' ? 'var(--success)' : 'var(--warning)'
          };">
            Status: ${
              quoteStatus === 'approved'
                ? 'Approved by worker — quotation sent & tentative slot held.'
                : 'Awaiting worker approval before contacting customer.'
            }
          </p>
        </div>
      </div>
    `;

    document.getElementById('btn-quote-edit')?.addEventListener('click', () => {
      const next = Number(document.getElementById('demo-quote-price')?.value || 350);
      state.agentDemo.customerQuotePrice = next > 0 ? next : 350;
      saveState();
      renderAgentWorkbench();
      showToast(`Quotation updated to ₹${state.agentDemo.customerQuotePrice}`);
    });

    document.getElementById('btn-quote-approve')?.addEventListener('click', () => {
      const next = Number(document.getElementById('demo-quote-price')?.value || 350);
      state.agentDemo.customerQuotePrice = next > 0 ? next : 350;
      state.agentDemo.customerQuoteStatus = 'approved';
      saveState();
      renderAgentWorkbench();
      showToast('Quotation approved and sent to Arjun Mehta.');
    });

    document.getElementById('btn-quote-reset')?.addEventListener('click', () => {
      state.agentDemo.customerQuoteStatus = 'awaiting_approval';
      state.agentDemo.customerQuotePrice = 350;
      saveState();
      renderAgentWorkbench();
    });
  } else if (tab === 'operations') {
    const tasks = state.agentDemo.operationsTasks;
    const completedCount = tasks.filter((t) => t.done).length;
    container.innerHTML = `
      <div class="demo-panel">
        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 16px;">
          <div>
            <h4 class="demo-panel__title" style="margin-bottom: 2px;">Daily Operations Queue</h4>
            <p style="font-size: 0.84rem; margin: 0;">Mark operational items complete to keep bookings, invoices and inventory current.</p>
          </div>
          <span class="mono" style="font-size: 0.85rem; font-weight: 600; color: var(--indigo);">
            ${completedCount} / ${tasks.length} Completed
          </span>
        </div>

        ${tasks
          .map(
            (t) => `
          <div class="task-item ${t.done ? 'is-done' : ''}">
            <div>
              <div style="font-weight: 600; color: var(--indigo); font-size: 0.92rem;">${escapeHtml(t.label)}</div>
              <div style="font-size: 0.78rem; color: var(--indigo-55);">${escapeHtml(t.tag)}</div>
            </div>
            <button type="button" class="btn ${t.done ? 'btn--secondary' : 'btn--primary'} btn--sm" data-toggle-task="${t.id}">
              ${t.done ? 'Reopen' : 'Mark Complete'}
            </button>
          </div>
        `
          )
          .join('')}

        <div style="margin-top: 14px; display: flex; justify-content: flex-end;">
          <button type="button" class="btn btn--ghost btn--sm" id="btn-reset-ops">Reset All Tasks</button>
        </div>
      </div>
    `;

    container.querySelectorAll('[data-toggle-task]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-toggle-task');
        const item = state.agentDemo.operationsTasks.find((x) => x.id === id);
        if (item) item.done = !item.done;
        saveState();
        renderAgentWorkbench();
      });
    });

    document.getElementById('btn-reset-ops')?.addEventListener('click', () => {
      state.agentDemo.operationsTasks.forEach((x) => (x.done = false));
      saveState();
      renderAgentWorkbench();
    });
  } else if (tab === 'reputation') {
    const tailor = state.businesses[0];
    const filter = state.agentDemo.reputationFilter || 'all';
    const reviews = tailor.reviews.filter((r) => {
      if (filter === '5star') return r.rating === 5;
      if (filter === 'repeat') return r.repeat;
      return true;
    });

    container.innerHTML = `
      <div class="demo-split">
        <div class="demo-panel">
          <h4 class="demo-panel__title">Portable Reputation Summary</h4>
          <div class="kv-list">
            <div class="kv-row"><span class="kv-key">Completed Jobs</span><span class="kv-val tabular-nums">148 Verified Jobs</span></div>
            <div class="kv-row"><span class="kv-key">Average Customer Rating</span><span class="kv-val tabular-nums">4.9 / 5.0 ★</span></div>
            <div class="kv-row"><span class="kv-key">Repeat Customer Rate</span><span class="kv-val tabular-nums" style="color: var(--success);">68% Repeat Buyers</span></div>
            <div class="kv-row"><span class="kv-key">Verified Referrals</span><span class="kv-val tabular-nums">29 Neighbourhood Referrals</span></div>
          </div>
        </div>

        <div class="demo-panel">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 14px;">
            <h4 class="demo-panel__title" style="margin: 0;">Recent Verified Reviews</h4>
            <div style="display: flex; gap: 6px;">
              <button type="button" class="filter-tab ${filter === 'all' ? 'is-active' : ''}" data-rep-filter="all">All</button>
              <button type="button" class="filter-tab ${filter === '5star' ? 'is-active' : ''}" data-rep-filter="5star">5 Star</button>
              <button type="button" class="filter-tab ${filter === 'repeat' ? 'is-active' : ''}" data-rep-filter="repeat">Repeat Clients</button>
            </div>
          </div>
          ${reviews
            .map(
              (r) => `
            <div class="review-item">
              <div style="display: flex; justify-content: space-between; font-size: 0.84rem; margin-bottom: 4px;">
                <strong>${escapeHtml(r.author)} · ${r.repeat ? 'Repeat Client' : 'Verified Buyer'}</strong>
                <span style="color: var(--coral); font-weight: 700;">${r.rating}.0 ★</span>
              </div>
              <p style="font-size: 0.88rem; margin: 0;">"${escapeHtml(r.text)}"</p>
            </div>
          `
            )
            .join('')}
        </div>
      </div>
    `;

    container.querySelectorAll('[data-rep-filter]').forEach((b) => {
      b.addEventListener('click', () => {
        state.agentDemo.reputationFilter = b.getAttribute('data-rep-filter');
        saveState();
        renderAgentWorkbench();
      });
    });
  } else if (tab === 'credit') {
    container.innerHTML = `
      <div class="demo-split">
        <div class="demo-panel">
          <h4 class="demo-panel__title">Financial Readiness Overview</h4>
          <div class="kv-list" style="margin-bottom: 16px;">
            <div class="kv-row"><span class="kv-key">Monthly Business Inflows</span><span class="kv-val tabular-nums">₹48,500</span></div>
            <div class="kv-row"><span class="kv-key">Completed Transactions (90d)</span><span class="kv-val tabular-nums">64 Recorded</span></div>
            <div class="kv-row"><span class="kv-key">Repeat Customer Trend</span><span class="kv-val tabular-nums" style="color: var(--success);">+14% Quarter-over-Quarter</span></div>
            <div class="kv-row"><span class="kv-key">Income Consistency</span><span class="kv-val" style="color: var(--success);">Steady (6 consecutive months)</span></div>
            <div class="kv-row"><span class="kv-key">Missing Financial Records</span><span class="kv-val" style="color: var(--warning);">2 cash receipts pending upload</span></div>
          </div>
          <button type="button" class="btn btn--primary" id="btn-demo-credit-passport">
            <i data-lucide="file-text"></i> Generate Credit Passport Preview
          </button>
        </div>

        <div class="demo-panel">
          <h4 class="demo-panel__title">Consent &amp; Transparency Notice</h4>
          <div class="notice-box">
            <strong>Important Prototype Disclosure:</strong><br/>
            The Credit-Readiness Passport structures a worker's own recorded bookings, invoices and repeat-customer metrics into a readable summary. It is <strong>not</strong> a guaranteed credit score, loan approval, or lending decision. Financial records are shared with lenders only after explicit worker consent.
          </div>
        </div>
      </div>
    `;

    document.getElementById('btn-demo-credit-passport')?.addEventListener('click', () => {
      openCreditPassportModal();
    });
  } else if (tab === 'growth') {
    container.innerHTML = `
      <div class="demo-split">
        <div class="demo-panel">
          <h4 class="demo-panel__title">AI Growth Recommendations</h4>
          <div class="kv-list">
            <div class="kv-row"><span class="kv-key">Promotional Offer Idea</span><span class="kv-val">10% off Festive Blouse + Fall Pico Bundle</span></div>
            <div class="kv-row"><span class="kv-key">Most Popular Service</span><span class="kv-val">Designer Blouse Stitching (42% orders)</span></div>
            <div class="kv-row"><span class="kv-key">Pricing Adjustment</span><span class="kv-val">Trouser Alteration: ₹120 → ₹150 (high weekend demand)</span></div>
            <div class="kv-row"><span class="kv-key">Catalogue Suggestion</span><span class="kv-val">Add "Express 24-Hour Stitching" add-on</span></div>
          </div>
        </div>

        <div class="demo-panel">
          <h4 class="demo-panel__title">ONDC-Compatible Listing Preview</h4>
          <div style="background: var(--bg-surface); border: 1px solid var(--indigo-12); border-radius: var(--radius-md); padding: 16px;">
            <div style="font-size: 0.76rem; color: var(--coral); font-weight: 700; margin-bottom: 4px;">ONDC / OPEN NETWORK READY SCHEMA</div>
            <div style="font-weight: 700; font-size: 1rem; color: var(--indigo); margin-bottom: 6px;">Aditi Tailoring Studio — Bridal &amp; Express Stitching</div>
            <p style="font-size: 0.85rem; margin-bottom: 10px;">Serviceability: 5 km radius (Lajpat Nagar) · Fulfilment: Drop-off &amp; Local Pickup</p>
            <div style="display: flex; justify-content: space-between; font-size: 0.85rem; padding-top: 10px; border-top: 1px solid var(--indigo-08);">
              <span>Catalogue Price: <strong class="tabular-nums">₹650</strong></span>
              <span style="color: var(--success); font-weight: 600;">Ready for Network Sync</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }
}

/* ==========================================================================
   Explore Businesses Marketplace
   ========================================================================== */
function renderExploreMarketplace() {
  const catContainer = document.getElementById('explore-categories');
  const grid = document.getElementById('explore-business-grid');
  if (!catContainer || !grid) return;

  const categories = ['All', ...new Set(state.businesses.map((b) => b.category))];
  catContainer.innerHTML = categories
    .map(
      (cat) => `
      <button type="button" class="filter-tab ${state.exploreFilter.category === cat ? 'is-active' : ''}" data-cat="${escapeHtml(cat)}">
        ${escapeHtml(cat)}
      </button>
    `
    )
    .join('');

  catContainer.querySelectorAll('[data-cat]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.exploreFilter.category = btn.getAttribute('data-cat');
      saveState();
      renderExploreMarketplace();
    });
  });

  const { search, location, category, sort } = state.exploreFilter;
  const q = search.trim().toLowerCase();

  let filtered = state.businesses.filter((b) => {
    const matchCat = category === 'All' || b.category === category;
    const matchLoc = location === 'all' || b.location.toLowerCase() === location.toLowerCase();
    const matchSearch =
      !q ||
      b.name.toLowerCase().includes(q) ||
      b.category.toLowerCase().includes(q) ||
      b.area.toLowerCase().includes(q) ||
      b.description.toLowerCase().includes(q) ||
      b.services.some((s) => s.name.toLowerCase().includes(q));
    return matchCat && matchLoc && matchSearch;
  });

  filtered.sort((a, b) => {
    if (sort === 'distance') return a.distanceKm - b.distanceKm;
    if (sort === 'popularity') return b.popularity - a.popularity;
    return b.rating - a.rating;
  });

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div class="panel" style="grid-column: 1 / -1; text-align: center; padding: 48px 24px;">
        <h3>No matching businesses found</h3>
        <p>Try clearing your search filter or viewing all categories.</p>
        <button type="button" class="btn btn--secondary" id="btn-clear-explore">Reset Filters</button>
      </div>
    `;
    document.getElementById('btn-clear-explore')?.addEventListener('click', () => {
      state.exploreFilter = { search: '', location: 'all', category: 'All', sort: 'rating' };
      document.getElementById('explore-search').value = '';
      document.getElementById('explore-location').value = 'all';
      saveState();
      renderExploreMarketplace();
    });
    return;
  }

  grid.innerHTML = filtered
    .map(
      (b) => `
      <article class="biz-card">
        <div class="biz-card__media">
          <img src="${escapeHtml(b.image)}" alt="${escapeHtml(b.name)}" referrerpolicy="no-referrer" />
        </div>
        <div class="biz-card__body">
          <div class="biz-card__meta">
            <span>${escapeHtml(b.category)}</span>
            <span aria-hidden="true">·</span>
            <span>${escapeHtml(b.location)} (${b.distanceKm} km)</span>
            ${
              b.verified
                ? `<span aria-hidden="true">·</span><span class="eco-verified"><i data-lucide="badge-check"></i> Verified</span>`
                : ''
            }
          </div>
          <h3 class="biz-card__title">${escapeHtml(b.name)}</h3>
          <p class="biz-card__desc">${escapeHtml(b.description)}</p>
          <div style="font-size: 0.82rem; color: var(--indigo); font-weight: 600; margin-bottom: 12px;">
            <span style="color: var(--coral);">★ ${b.rating.toFixed(1)}</span> · ${b.completedJobs} jobs · ${b.repeatRate}% repeat buyers
          </div>
          <div class="biz-card__footer">
            <div class="biz-card__price">
              Starts from
              <strong class="tabular-nums">₹${b.startingPrice}</strong>
            </div>
            <button type="button" class="btn btn--indigo btn--sm" data-open-store="${escapeHtml(b.id)}">
              View Store
            </button>
          </div>
        </div>
      </article>
    `
    )
    .join('');

  grid.querySelectorAll('[data-open-store]').forEach((btn) => {
    btn.addEventListener('click', () => {
      switchView('storefront', { storeId: btn.getAttribute('data-open-store') });
    });
  });

  refreshIcons();
}

/* ==========================================================================
   Individual Digital Storefront + 6-Step Customer Booking Flow
   ========================================================================== */
function renderStorefront() {
  const container = document.getElementById('view-storefront');
  if (!container) return;

  const biz =
    state.businesses.find((b) => b.id === state.activeStoreId) || state.businesses[0];

  container.innerHTML = `
    <div class="container storefront-wrap">
      <div class="breadcrumb-bar">
        <button type="button" class="btn btn--secondary btn--sm" id="btn-store-back">
          <i data-lucide="arrow-left"></i> Back to Explore Businesses
        </button>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
          <button type="button" class="btn btn--secondary btn--sm" id="btn-store-share">
            <i data-lucide="share-2"></i> Share Store
          </button>
          <button type="button" class="btn btn--primary btn--sm" id="btn-store-scroll-book">
            Book Now
          </button>
        </div>
      </div>

      <div class="storefront-hero">
        <div class="storefront-hero__info">
          <div>
            <div class="eco-meta-line" style="margin-bottom: 10px;">
              ${
                biz.verified
                  ? '<span class="eco-verified"><i data-lucide="badge-check"></i> Verified DukaanID</span><span aria-hidden="true">·</span>'
                  : ''
              }
              <span>${escapeHtml(biz.category)}</span>
              <span aria-hidden="true">·</span>
              <span>${escapeHtml(biz.area)}</span>
            </div>
            <h1 style="font-size: clamp(1.75rem, 3vw, 2.5rem); margin-bottom: 10px;">${escapeHtml(biz.name)}</h1>
            <p style="font-size: 1rem;">${escapeHtml(biz.description)}</p>
          </div>

          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; padding-top: 18px; border-top: 1px solid var(--indigo-08); margin-top: 14px;">
            <div>
              <div style="font-size: 0.78rem; color: var(--indigo-55);">Rating</div>
              <strong class="tabular-nums" style="font-size: 1.15rem;">★ ${biz.rating.toFixed(1)} / 5.0</strong>
            </div>
            <div>
              <div style="font-size: 0.78rem; color: var(--indigo-55);">Completed Jobs</div>
              <strong class="tabular-nums" style="font-size: 1.15rem;">${biz.completedJobs}</strong>
            </div>
            <div>
              <div style="font-size: 0.78rem; color: var(--indigo-55);">Repeat Customers</div>
              <strong class="tabular-nums" style="font-size: 1.15rem; color: var(--success);">${biz.repeatRate}%</strong>
            </div>
          </div>
        </div>
        <div class="storefront-hero__media">
          <img src="${escapeHtml(biz.image)}" alt="${escapeHtml(biz.name)}" referrerpolicy="no-referrer" />
        </div>
      </div>

      <div class="storefront-grid">
        <div>
          <div class="panel">
            <h2 style="font-size: 1.3rem; margin-bottom: 16px;">Services &amp; Transparent Pricing</h2>
            ${biz.services
              .map(
                (s, idx) => `
              <div class="service-item">
                <div>
                  <div style="font-weight: 700; color: var(--indigo);">${escapeHtml(s.name)}</div>
                  <div style="font-size: 0.82rem; color: var(--indigo-55);">Turnaround: ${escapeHtml(s.duration)}</div>
                </div>
                <div style="display: flex; align-items: center; gap: 14px;">
                  <strong class="tabular-nums" style="font-size: 1.05rem;">₹${s.price}</strong>
                  <button type="button" class="btn btn--secondary btn--sm" data-book-service-idx="${idx}">Select</button>
                </div>
              </div>
            `
              )
              .join('')}
          </div>

          <div class="panel">
            <h2 style="font-size: 1.3rem; margin-bottom: 14px;">Verified Customer Reviews</h2>
            ${biz.reviews
              .map(
                (r) => `
              <div class="review-item">
                <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                  <strong>${escapeHtml(r.author)} ${r.repeat ? '· Repeat Customer' : ''}</strong>
                  <span style="color: var(--coral); font-weight: 700;">★ ${r.rating}.0</span>
                </div>
                <p style="margin: 0 0 4px;">"${escapeHtml(r.text)}"</p>
                <span style="font-size: 0.78rem; color: var(--indigo-55);">${escapeHtml(r.date)}</span>
              </div>
            `
              )
              .join('')}
          </div>
        </div>

        <div>
          <div class="panel" id="storefront-booking-panel">
            <h3 style="font-size: 1.2rem; margin-bottom: 6px;">Book a Service</h3>
            <p style="font-size: 0.84rem; margin-bottom: 16px;">${escapeHtml(biz.availability)}</p>
            <div id="booking-flow-box"></div>
          </div>

          <div class="panel">
            <h3 style="font-size: 1.1rem; margin-bottom: 12px;">Contact &amp; QR Store Card</h3>
            <div class="kv-list" style="margin-bottom: 16px;">
              <div class="kv-row"><span class="kv-key">Owner</span><span class="kv-val">${escapeHtml(biz.owner)}</span></div>
              <div class="kv-row"><span class="kv-key">Phone</span><span class="kv-val mono">${escapeHtml(biz.phone)}</span></div>
              <div class="kv-row"><span class="kv-key">Hours</span><span class="kv-val">${escapeHtml(biz.hours)}</span></div>
            </div>
            <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 16px;">
              <div style="padding: 8px; background: var(--bg-cream); border: 1px solid var(--indigo-12); border-radius: 10px;">
                ${generateQrSvg(biz.id, 78)}
              </div>
              <div>
                <div style="font-weight: 700; font-size: 0.92rem;">Scan QR to Visit Store</div>
                <div class="mono" style="font-size: 0.78rem; color: var(--coral);">${escapeHtml(buildStoreUrl(biz.id))}</div>
              </div>
            </div>
            <button type="button" class="btn btn--success" style="width: 100%;" id="btn-store-whatsapp">
              <i data-lucide="message-circle"></i> WhatsApp Contact
            </button>
          </div>
        </div>
      </div>
    </div>
  `;

  document.getElementById('btn-store-back')?.addEventListener('click', () => {
    switchView('landing', { scrollTo: 'explore' });
  });
  document.getElementById('btn-store-scroll-book')?.addEventListener('click', () => {
    document.getElementById('storefront-booking-panel')?.scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('btn-store-share')?.addEventListener('click', () => {
    openModal(
      'Share Digital Storefront',
      `
        <p>Share <strong>${escapeHtml(biz.name)}</strong> directly with customers via WhatsApp or QR code.</p>
        <div style="display: flex; justify-content: center; margin: 16px 0;">
          <div style="padding: 14px; background: var(--bg-cream); border: 1px solid var(--indigo-12); border-radius: 12px;">
            ${generateQrSvg(biz.id, 140)}
          </div>
        </div>
        <label class="field-label">Shareable Link</label>
        <div style="display: flex; gap: 8px;">
          <input type="text" class="input mono" readonly value="${escapeHtml(buildStoreUrl(biz.id))}" id="copy-store-url" />
          <button type="button" class="btn btn--primary btn--sm" id="btn-copy-url-confirm">Copy</button>
        </div>
      `
    );
    document.getElementById('btn-copy-url-confirm')?.addEventListener('click', () => {
      navigator.clipboard?.writeText(buildStoreUrl(biz.id)).catch(() => {});
      showToast('Storefront link copied to clipboard.');
    });
  });

  document.getElementById('btn-store-whatsapp')?.addEventListener('click', () => {
    openModal('WhatsApp Contact Preview', `<p>No message is sent from this prototype. You can use the contact details below in a real WhatsApp integration.</p><div class="notice-box"><strong>${escapeHtml(biz.name)}</strong><br/>${escapeHtml(biz.phone)}</div><a class="btn btn--success" href="https://wa.me/${biz.phone.replace(/[^0-9]/g, '')}" target="_blank" rel="noopener">Continue to WhatsApp</a>`);
  });

  let bookingStep = 1;
  const bookingData = {
    serviceIdx: 0,
    date: '2026-11-15',
    time: '11:00 AM',
    customerName: '',
    customerPhone: ''
  };

  function renderBookingStep() {
    const box = document.getElementById('booking-flow-box');
    if (!box) return;
    const selectedService = biz.services[bookingData.serviceIdx] || biz.services[0];

    if (bookingStep === 1) {
      box.innerHTML = `
        <div style="font-size: 0.78rem; font-weight: 700; color: var(--coral); margin-bottom: 8px;">STEP 1 OF 4 · SELECT SERVICE</div>
        <label for="bk-service" class="field-label">Service</label>
        <select id="bk-service" class="select" style="margin-bottom: 14px;">
          ${biz.services
            .map((s, i) => `<option value="${i}" ${i === bookingData.serviceIdx ? 'selected' : ''}>${escapeHtml(s.name)} — ₹${s.price}</option>`)
            .join('')}
        </select>
        <button type="button" class="btn btn--primary" style="width: 100%;" id="bk-next-1">Continue to Date &amp; Time</button>
      `;
      document.getElementById('bk-next-1')?.addEventListener('click', () => {
        bookingData.serviceIdx = Number(document.getElementById('bk-service').value);
        bookingStep = 2;
        renderBookingStep();
      });
    } else if (bookingStep === 2) {
      box.innerHTML = `
        <div style="font-size: 0.78rem; font-weight: 700; color: var(--coral); margin-bottom: 8px;">STEP 2 OF 4 · CHOOSE DATE &amp; TIME</div>
        <label for="bk-date" class="field-label">Preferred Date</label>
        <input type="date" id="bk-date" class="input" value="${bookingData.date}" style="margin-bottom: 12px;" />
        <label for="bk-time" class="field-label">Time Slot</label>
        <select id="bk-time" class="select" style="margin-bottom: 14px;">
          <option value="10:30 AM" ${bookingData.time === '10:30 AM' ? 'selected' : ''}>10:30 AM</option>
          <option value="11:00 AM" ${bookingData.time === '11:00 AM' ? 'selected' : ''}>11:00 AM</option>
          <option value="02:30 PM" ${bookingData.time === '02:30 PM' ? 'selected' : ''}>02:30 PM</option>
          <option value="05:00 PM" ${bookingData.time === '05:00 PM' ? 'selected' : ''}>05:00 PM</option>
        </select>
        <div style="display: flex; gap: 8px;">
          <button type="button" class="btn btn--secondary btn--sm" id="bk-back-2">Back</button>
          <button type="button" class="btn btn--primary" style="flex: 1;" id="bk-next-2">Enter Details</button>
        </div>
      `;
      document.getElementById('bk-back-2')?.addEventListener('click', () => {
        bookingStep = 1;
        renderBookingStep();
      });
      document.getElementById('bk-next-2')?.addEventListener('click', () => {
        bookingData.date = document.getElementById('bk-date').value || '2026-11-15';
        bookingData.time = document.getElementById('bk-time').value;
        bookingStep = 3;
        renderBookingStep();
      });
    } else if (bookingStep === 3) {
      box.innerHTML = `
        <div style="font-size: 0.78rem; font-weight: 700; color: var(--coral); margin-bottom: 8px;">STEP 3 OF 4 · YOUR CONTACT DETAILS</div>
        <label for="bk-name" class="field-label">Your Name</label>
        <input type="text" id="bk-name" class="input" placeholder="e.g. Riya Kapoor" value="${escapeHtml(bookingData.customerName)}" style="margin-bottom: 10px;" />
        <label for="bk-phone" class="field-label">Mobile Number</label>
        <input type="tel" id="bk-phone" class="input" placeholder="+91 98XXXXXXXX" value="${escapeHtml(bookingData.customerPhone)}" style="margin-bottom: 14px;" />
        <div class="notice-box" style="margin-bottom: 14px;">
          <strong>${escapeHtml(selectedService.name)}</strong><br/>
          ${escapeHtml(bookingData.date)} at ${escapeHtml(bookingData.time)} · <strong class="tabular-nums">₹${selectedService.price}</strong>
        </div>
        <div style="display: flex; gap: 8px;">
          <button type="button" class="btn btn--secondary btn--sm" id="bk-back-3">Back</button>
          <button type="button" class="btn btn--primary" style="flex: 1;" id="bk-submit">Submit Booking Request</button>
        </div>
      `;
      document.getElementById('bk-back-3')?.addEventListener('click', () => {
        bookingStep = 2;
        renderBookingStep();
      });
      document.getElementById('bk-submit')?.addEventListener('click', () => {
        const name = document.getElementById('bk-name').value.trim();
        const phone = document.getElementById('bk-phone').value.trim();
        if (!name || !phone) {
          showToast('Please enter your name and mobile number.');
          return;
        }
        bookingData.customerName = name;
        bookingData.customerPhone = phone;

        const newId = 'BK-' + Math.floor(910 + Math.random() * 89);
        state.bookings.unshift({
          id: newId,
          customer: name,
          phone,
          service: selectedService.name,
          date: bookingData.date,
          time: bookingData.time,
          amount: selectedService.price,
          status: 'Pending'
        });
        logActivity('New booking request received', `${name} requested ${selectedService.name} for ${bookingData.date} at ${bookingData.time}.`, 'Customer');
        saveState();
        bookingStep = 4;
        renderBookingStep();
        showToast('Booking request submitted!');
      });
    } else {
      box.innerHTML = `
        <div style="text-align: center; padding: 10px 0;">
          <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--success-bg); color: var(--success); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 10px;">
            <i data-lucide="check"></i>
          </div>
          <h4 style="margin-bottom: 6px;">Booking Request Sent!</h4>
          <p style="font-size: 0.88rem; margin-bottom: 14px;">
            Thank you, <strong>${escapeHtml(bookingData.customerName)}</strong>. ${escapeHtml(biz.owner)} has received your request for <strong>${escapeHtml(selectedService.name)}</strong> on ${escapeHtml(bookingData.date)} (${escapeHtml(bookingData.time)}).
          </p>
          <button type="button" class="btn btn--secondary btn--sm" id="bk-another">Book Another Service</button>
        </div>
      `;
      refreshIcons();
      document.getElementById('bk-another')?.addEventListener('click', () => {
        bookingStep = 1;
        renderBookingStep();
      });
    }
  }

  container.querySelectorAll('[data-book-service-idx]').forEach((btn) => {
    btn.addEventListener('click', () => {
      bookingData.serviceIdx = Number(btn.getAttribute('data-book-service-idx'));
      bookingStep = 2;
      renderBookingStep();
      document.getElementById('storefront-booking-panel')?.scrollIntoView({ behavior: 'smooth' });
    });
  });

  renderBookingStep();
  refreshIcons();
}

/* ==========================================================================
   Worker Onboarding Experience (8 Steps)
   ========================================================================== */
function renderOnboarding() {
  const container = document.getElementById('view-onboarding');
  if (!container) return;

  const d = state.onboardingDraft;
  const step = d.step;
  const pct = Math.round((step / 8) * 100);

  let stepHtml = '';

  if (step === 1) {
    stepHtml = `
      <span class="section-kicker">STEP 1 OF 8 · WELCOME</span>
      <h2>Welcome to DukaanID</h2>
      <p>Create your verified digital business identity, QR storefront and reputation wallet in under 2 minutes — no technical setup required.</p>
      <div class="notice-box" style="margin: 20px 0;">
        <strong>Prototype Demo Mode:</strong> No real OTP or documents are required. Everything you create is saved locally in your browser so you can preview your live storefront immediately.
      </div>
      <div style="display: flex; justify-content: space-between; margin-top: 24px;">
        <button type="button" class="btn btn--ghost" id="onb-exit">Back to Home</button>
        <button type="button" class="btn btn--primary" id="onb-next">Let's Get Started <i data-lucide="arrow-right"></i></button>
      </div>
    `;
  } else if (step === 2) {
    stepHtml = `
      <span class="section-kicker">STEP 2 OF 8 · OWNER DETAILS</span>
      <h2>Enter Your Name &amp; Mobile Number</h2>
      <p>Customers will see your name and verified contact number on your storefront.</p>
      <div style="display: grid; gap: 14px; margin: 20px 0;">
        <div>
          <label for="onb-name" class="field-label">Your Full Name / Business Name</label>
          <input type="text" id="onb-name" class="input" placeholder="e.g. Sunita Devi / Sunita Tailors" value="${escapeHtml(d.name)}" />
        </div>
        <div>
          <label for="onb-phone" class="field-label">Mobile Number (No OTP needed)</label>
          <input type="tel" id="onb-phone" class="input" placeholder="+91 98XXXXXXXX" value="${escapeHtml(d.phone)}" />
        </div>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn--secondary" id="onb-prev">Back</button>
        <button type="button" class="btn btn--primary" id="onb-next">Continue</button>
      </div>
    `;
  } else if (step === 3) {
    const cats = ['Tailoring', 'Home Food', 'Electrical', 'Plumbing', 'Beauty', 'Handicrafts'];
    stepHtml = `
      <span class="section-kicker">STEP 3 OF 8 · SKILL CATEGORY</span>
      <h2>Select Your Business Category</h2>
      <p>Choose the primary skill that best describes your work.</p>
      <div class="category-grid" style="margin: 20px 0;">
        ${cats
          .map(
            (c) => `
          <button type="button" class="category-choice ${d.category === c ? 'is-selected' : ''}" data-onb-cat="${c}">
            ${escapeHtml(c)}
          </button>
        `
          )
          .join('')}
      </div>
      <div style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn--secondary" id="onb-prev">Back</button>
        <button type="button" class="btn btn--primary" id="onb-next">Continue</button>
      </div>
    `;
  } else if (step === 4) {
    stepHtml = `
      <span class="section-kicker">STEP 4 OF 8 · DESCRIBE YOUR BUSINESS</span>
      <h2>Describe Your Work (Text or Voice)</h2>
      <p>Type a short note or click our simulated voice assistant to capture your business story automatically.</p>
      <div style="margin: 18px 0;">
        <button type="button" class="btn btn--indigo btn--sm" id="btn-sim-voice" style="margin-bottom: 12px;">
          <i data-lucide="mic"></i> Simulate Voice Input (Hindi / English)
        </button>
        <textarea id="onb-desc" class="textarea" placeholder="Tell customers about your experience, specialty and service area...">${escapeHtml(d.description)}</textarea>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn--secondary" id="onb-prev">Back</button>
        <button type="button" class="btn btn--primary" id="onb-next">Continue</button>
      </div>
    `;
  } else if (step === 5) {
    stepHtml = `
      <span class="section-kicker">STEP 5 OF 8 · WORK PHOTOGRAPHS</span>
      <h2>Upload Business Photographs</h2>
      <p>Add photos of your shop, finished work or tools. You can upload an image or pick from sample studio photos.</p>
      <div style="margin: 18px 0;">
        <input type="file" id="onb-photo-upload" accept="image/*" class="input" style="margin-bottom: 12px;" />
        <div class="preset-row">
          <button type="button" class="btn btn--secondary btn--sm" data-preset-img="${imgTailor}">Tailoring Sample</button>
          <button type="button" class="btn btn--secondary btn--sm" data-preset-img="${imgKitchen}">Kitchen Sample</button>
          <button type="button" class="btn btn--secondary btn--sm" data-preset-img="${imgArtisan}">Artisan Sample</button>
        </div>
        <div class="photo-preview-grid">
          ${d.photos
            .map(
              (src) => `<div class="photo-preview-box"><img src="${escapeHtml(src)}" alt="Uploaded business preview" referrerpolicy="no-referrer" /></div>`
            )
            .join('')}
        </div>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn--secondary" id="onb-prev">Back</button>
        <button type="button" class="btn btn--primary" id="onb-next">Continue</button>
      </div>
    `;
  } else if (step === 6) {
    stepHtml = `
      <span class="section-kicker">STEP 6 OF 8 · SERVICES &amp; PRICING</span>
      <h2>Add Services &amp; Starting Prices</h2>
      <p>Clear starting prices help local customers book faster without hesitation.</p>
      <div style="margin: 16px 0;" id="onb-services-list">
        ${d.services
          .map(
            (s, i) => `
          <div style="display: grid; grid-template-columns: 1.5fr 0.8fr auto; gap: 10px; margin-bottom: 10px;">
            <input type="text" class="input" value="${escapeHtml(s.name)}" data-srv-name="${i}" placeholder="Service name" />
            <input type="number" class="input tabular-nums" value="${s.price}" data-srv-price="${i}" placeholder="₹ Price" />
            <button type="button" class="btn btn--danger-outline btn--sm" data-srv-del="${i}">Remove</button>
          </div>
        `
          )
          .join('')}
      </div>
      <button type="button" class="btn btn--secondary btn--sm" id="btn-add-srv" style="margin-bottom: 20px;">+ Add Another Service</button>
      <div style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn--secondary" id="onb-prev">Back</button>
        <button type="button" class="btn btn--primary" id="onb-next">Continue</button>
      </div>
    `;
  } else if (step === 7) {
    stepHtml = `
      <span class="section-kicker">STEP 7 OF 8 · LOCATION &amp; HOURS</span>
      <h2>Add Location &amp; Working Hours</h2>
      <p>Let nearby customers know where you operate and when you accept bookings.</p>
      <div style="display: grid; gap: 14px; margin: 20px 0;">
        <div>
          <label for="onb-loc" class="field-label">City / Neighbourhood</label>
          <input type="text" id="onb-loc" class="input" value="${escapeHtml(d.location)}" placeholder="e.g. South Delhi" />
        </div>
        <div>
          <label for="onb-hours" class="field-label">Business Hours</label>
          <input type="text" id="onb-hours" class="input" value="${escapeHtml(d.hours)}" placeholder="e.g. 10:00 AM – 8:00 PM" />
        </div>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <button type="button" class="btn btn--secondary" id="onb-prev">Back</button>
        <button type="button" class="btn btn--primary" id="onb-generate">Generate My DukaanID <i data-lucide="sparkles"></i></button>
      </div>
    `;
  } else {
    const biz =
      state.businesses.find((b) => b.id === d.createdBusinessId) || state.businesses[0];
    stepHtml = `
      <div style="text-align: center; padding: 10px 0;">
        <div style="width: 58px; height: 58px; border-radius: 50%; background: var(--success-bg); color: var(--success); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 14px;">
          <i data-lucide="badge-check" style="width: 30px; height: 30px;"></i>
        </div>
        <h2>Congratulations! Your DukaanID is ready.</h2>
        <p>Your digital storefront, QR code and verified skill profile are now live in this prototype.</p>

        <div class="panel" style="text-align: left; margin: 24px 0; display: grid; grid-template-columns: auto 1fr; gap: 22px; align-items: center;">
          <div style="padding: 10px; background: var(--bg-cream); border: 1px solid var(--indigo-12); border-radius: 12px;">
            ${generateQrSvg(biz.id, 118)}
          </div>
          <div>
            <div style="font-size: 0.78rem; color: var(--coral); font-weight: 700;">VERIFIED DUKAANID</div>
            <h3 style="margin: 4px 0;">${escapeHtml(biz.name)}</h3>
            <p style="font-size: 0.88rem; margin-bottom: 8px;">${escapeHtml(biz.category)} · ${escapeHtml(biz.area)}</p>
            <div class="mono" style="font-size: 0.84rem; color: var(--indigo);">${escapeHtml(buildStoreUrl(biz.id))}</div>
          </div>
        </div>

        <div style="display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;">
          <button type="button" class="btn btn--primary" id="onb-view-store">View My Store</button>
          <button type="button" class="btn btn--indigo" id="onb-go-dash">Go to Worker Dashboard</button>
          <button type="button" class="btn btn--secondary" id="onb-start-over">Create Another</button>
        </div>
      </div>
    `;
  }

  container.innerHTML = `
    <div class="container onboarding-wrap">
      <div class="onboarding-shell">
        <div class="onboarding-progress">
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.86rem; font-weight: 600;">
            <span>Worker Digital Identity Setup</span>
            <span class="tabular-nums">${pct}% Complete</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width: ${pct}%;"></div>
          </div>
        </div>
        <div class="onboarding-body">${stepHtml}</div>
      </div>
    </div>
  `;

  document.getElementById('onb-exit')?.addEventListener('click', () => switchView('landing'));
  document.getElementById('onb-prev')?.addEventListener('click', () => {
    d.step = Math.max(1, step - 1);
    saveState();
    renderOnboarding();
  });

  document.getElementById('onb-next')?.addEventListener('click', () => {
    if (step === 2) {
      d.name = document.getElementById('onb-name').value.trim() || 'Sunita Devi Studio';
      d.phone = document.getElementById('onb-phone').value.trim() || '+91 98100 11223';
    } else if (step === 4) {
      d.description =
        document.getElementById('onb-desc').value.trim() ||
        `Quality ${d.category.toLowerCase()} services with transparent pricing and timely delivery.`;
    } else if (step === 6) {
      syncOnboardingServices();
    }
    d.step = Math.min(8, step + 1);
    saveState();
    renderOnboarding();
  });

  function syncOnboardingServices() {
    container.querySelectorAll('[data-srv-name]').forEach((inp) => {
      const idx = Number(inp.getAttribute('data-srv-name'));
      if (d.services[idx]) d.services[idx].name = inp.value.trim() || 'Standard Service';
    });
    container.querySelectorAll('[data-srv-price]').forEach((inp) => {
      const idx = Number(inp.getAttribute('data-srv-price'));
      if (d.services[idx]) d.services[idx].price = Number(inp.value) || 150;
    });
  }

  container.querySelectorAll('[data-onb-cat]').forEach((b) => {
    b.addEventListener('click', () => {
      d.category = b.getAttribute('data-onb-cat');
      saveState();
      renderOnboarding();
    });
  });

  document.getElementById('btn-sim-voice')?.addEventListener('click', () => {
    const sample = `Namaste! I offer experienced ${d.category.toLowerCase()} services in ${d.location || 'Delhi'} with neat work, fair rates and timely home delivery.`;
    const ta = document.getElementById('onb-desc');
    if (ta) ta.value = sample;
    d.description = sample;
    saveState();
    showToast('Voice note transcribed into your business description.');
  });

  document.getElementById('onb-photo-upload')?.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        d.photos = [reader.result, ...d.photos.slice(0, 2)];
        saveState();
        renderOnboarding();
        showToast('Photo uploaded to your storefront gallery.');
      }
    };
    reader.readAsDataURL(file);
  });

  container.querySelectorAll('[data-preset-img]').forEach((b) => {
    b.addEventListener('click', () => {
      const src = b.getAttribute('data-preset-img');
      if (!d.photos.includes(src)) d.photos.unshift(src);
      saveState();
      renderOnboarding();
    });
  });

  container.querySelectorAll('[data-srv-del]').forEach((b) => {
    b.addEventListener('click', () => {
      syncOnboardingServices();
      const idx = Number(b.getAttribute('data-srv-del'));
      if (d.services.length > 1) {
        d.services.splice(idx, 1);
        saveState();
        renderOnboarding();
      }
    });
  });

  document.getElementById('btn-add-srv')?.addEventListener('click', () => {
    syncOnboardingServices();
    d.services.push({ name: 'New Service Item', price: 250 });
    saveState();
    renderOnboarding();
  });

  document.getElementById('onb-generate')?.addEventListener('click', () => {
    d.location = document.getElementById('onb-loc').value.trim() || 'Delhi';
    d.hours = document.getElementById('onb-hours').value.trim() || '10:00 AM – 8:00 PM';

    const slug =
      (d.name || 'local-worker')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') +
      '-' +
      Math.floor(100 + Math.random() * 899);

    const minPrice = Math.min(...d.services.map((s) => Number(s.price) || 150));
    const newBiz = {
      id: slug,
      name: d.name || 'My Verified Dukaan',
      owner: d.name || 'Worker Partner',
      category: d.category,
      location: d.location.split(',')[0].trim() || 'Delhi',
      area: d.location,
      phone: d.phone || '+91 98100 11223',
      distanceKm: 0.6,
      rating: 5.0,
      popularity: 95,
      verified: true,
      completedJobs: 1,
      repeatRate: 100,
      startingPrice: minPrice,
      hours: d.hours,
      availability: 'Booking slots open today',
      image: d.photos[0] || imgTailor,
      description:
        d.description ||
        `Verified ${d.category.toLowerCase()} specialist operating in ${d.location}.`,
      services: d.services.map((s) => ({
        name: s.name,
        duration: 'Same day',
        price: Number(s.price) || 150
      })),
      reviews: [
        {
          author: 'First Verified Customer',
          rating: 5,
          repeat: false,
          service: d.category,
          date: 'Just now',
          text: 'Prompt service and very clear pricing on DukaanID.'
        }
      ]
    };

    state.businesses.unshift(newBiz);
    d.createdBusinessId = slug;
    d.step = 8;
    saveState();
    renderExploreMarketplace();
    renderOnboarding();
    showToast('Your DukaanID is live!');
  });

  document.getElementById('onb-view-store')?.addEventListener('click', () => {
    switchView('storefront', { storeId: d.createdBusinessId || state.businesses[0].id });
  });
  document.getElementById('onb-go-dash')?.addEventListener('click', () => {
    switchView('dashboard', { dashTab: 'overview' });
  });
  document.getElementById('onb-start-over')?.addEventListener('click', () => {
    state.onboardingDraft = getInitialState().onboardingDraft;
    saveState();
    renderOnboarding();
  });

  refreshIcons();
}

/* ==========================================================================
   Worker Dashboard (11 Complete Modules + Chart.js + Floating AI)
   ========================================================================== */
const DASH_TABS = [
  { id: 'overview', label: 'Overview', icon: 'layout-dashboard' },
  { id: 'profile', label: 'My DukaanID', icon: 'id-card' },
  { id: 'storefront', label: 'Storefront', icon: 'store' },
  { id: 'assistants', label: 'AI Assistants', icon: 'bot' },
  { id: 'bookings', label: 'Bookings', icon: 'calendar-check' },
  { id: 'customers', label: 'Customers', icon: 'users' },
  { id: 'reputation', label: 'Reputation Wallet', icon: 'award' },
  { id: 'payments', label: 'Payments & Invoices', icon: 'receipt' },
  { id: 'credit', label: 'Credit Passport', icon: 'landmark' },
  { id: 'growth', label: 'Growth Insights', icon: 'trending-up' },
  { id: 'settings', label: 'Settings', icon: 'settings' }
];

function renderDashboard() {
  const container = document.getElementById('view-dashboard');
  if (!container) return;

  if (overviewChartInstance) {
    overviewChartInstance.destroy();
    overviewChartInstance = null;
  }
  if (creditChartInstance) {
    creditChartInstance.destroy();
    creditChartInstance = null;
  }

  const profile = state.workerProfile;
  const activeTab = state.activeDashTab || 'overview';

  container.innerHTML = `
    <div class="dashboard-layout">
      <aside class="dashboard-sidebar" aria-label="Dashboard Sidebar">
        <div>
          <div class="sidebar-profile">
            <div class="sidebar-profile__name">${escapeHtml(profile.businessName)}</div>
            <p class="sidebar-profile__meta mono">${escapeHtml(profile.id)} · Verified</p>
          </div>
          <nav class="sidebar-nav">
            ${DASH_TABS.map(
              (t) => `
              <button type="button" class="sidebar-link ${activeTab === t.id ? 'is-active' : ''}" data-dash-tab="${t.id}">
                <i data-lucide="${t.icon}"></i>
                <span>${t.label}</span>
              </button>
            `
            ).join('')}
          </nav>
        </div>

        <div style="padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.12); margin-top: 20px;">
          <button type="button" class="sidebar-link" id="btn-dash-exit-public" style="width: 100%;">
            <i data-lucide="arrow-left"></i>
            <span>Back to Public Site</span>
          </button>
        </div>
      </aside>

      <div class="dashboard-main" id="dashboard-main-content"></div>
    </div>

    <button type="button" class="floating-ai-btn" id="btn-floating-ai">
      <i data-lucide="sparkles"></i>
      <span>AI Business Assistant</span>
    </button>
  `;

  container.querySelectorAll('[data-dash-tab]').forEach((b) => {
    b.addEventListener('click', () => {
      state.activeDashTab = b.getAttribute('data-dash-tab');
      saveState();
      renderDashboard();
    });
  });

  document.getElementById('btn-dash-exit-public')?.addEventListener('click', () => {
    switchView('landing');
  });

  document.getElementById('btn-floating-ai')?.addEventListener('click', () => {
    openFloatingAiModal();
  });

  renderDashboardTabContent(activeTab);
  refreshIcons();
}

function renderDashboardTabContent(tab) {
  const main = document.getElementById('dashboard-main-content');
  if (!main) return;
  const profile = state.workerProfile;

  const totalRevenue = state.invoices.reduce((acc, inv) => acc + (inv.status === 'Paid' ? inv.amount : 0), 0);
  const pendingBookingsCount = state.bookings.filter((b) => b.status === 'Pending').length;
  const confirmedBookingsCount = state.bookings.filter((b) => b.status === 'Confirmed').length;

  if (tab === 'overview') {
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.85rem; margin-bottom: 4px;">Good morning, ${escapeHtml(profile.ownerName.split(' ')[0])}!</h1>
          <p style="margin: 0;">Here's what's happening with your business today.</p>
        </div>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
          <button type="button" class="btn btn--secondary btn--sm" id="dash-view-live-store">View Live Storefront</button>
          <button type="button" class="btn btn--primary btn--sm" id="dash-quick-invoice">+ Create Invoice</button>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-card__label">Total Enquiries</div>
          <div class="kpi-card__value tabular-nums">${state.bookings.length}</div>
          <p class="kpi-card__sub">Bookings and enquiries in this demo</p>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Confirmed Bookings</div>
          <div class="kpi-card__value tabular-nums">${confirmedBookingsCount}</div>
          <p class="kpi-card__sub">${pendingBookingsCount} awaiting approval</p>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Monthly Revenue</div>
          <div class="kpi-card__value tabular-nums">₹${totalRevenue.toLocaleString('en-IN')}</div>
          <p class="kpi-card__sub">Sample tracked inflows</p>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Customer Rating</div>
          <div class="kpi-card__value tabular-nums">${(state.businesses.find(x => x.id === "meena-kitchen")?.rating || 4.9).toFixed(1)} ★</div>
          <p class="kpi-card__sub">${state.businesses.find(x => x.id === "meena-kitchen")?.repeatRate || 0}% repeat buyers</p>
        </div>
      </div>

      <div class="panel" style="margin: 18px 0;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
          <div><h3 style="font-size:1.08rem;margin:0 0 3px;">AI Agent Activity Centre</h3><p style="font-size:.82rem;margin:0;color:var(--indigo-55);">A transparent timeline of demo agent actions and approvals.</p></div>
          <span class="status-text status-text--success">Demo activity</span>
        </div>
        <div class="kv-list">${(state.activityLog || []).slice(0,4).map(a => `<div class="kv-row"><div><strong>${escapeHtml(a.title)}</strong><p style="font-size:.82rem;margin:3px 0 0;">${escapeHtml(a.detail)}</p><span style="font-size:.74rem;color:var(--indigo-55);">${escapeHtml(a.type)} · ${escapeHtml(a.time)}</span></div></div>`).join('')}</div>
      </div>

      <div class="dash-grid-2">
        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem; margin-bottom: 14px;">Revenue Overview (Tracked Paid Invoices)</h3>
          <div class="chart-box"><canvas id="chart-overview-rev"></canvas></div>
        </div>

        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem; margin-bottom: 14px;">AI-Generated Business Insights</h3>
          <div class="kv-list">
            <div class="kv-row">
              <div>
                <strong>Lunch Tiffin Demand Peak</strong>
                <p style="font-size: 0.82rem; margin: 2px 0 0;">Tue–Thu office orders rose 22%. Consider opening 5 extra meal slots.</p>
              </div>
            </div>
            <div class="kv-row">
              <div>
                <strong>2 Unpaid Invoices Reminder</strong>
                <p style="font-size: 0.82rem; margin: 2px 0 0;">₹2,290 pending from recent deliveries. Send polite WhatsApp reminders.</p>
              </div>
            </div>
            <div class="kv-row">
              <div>
                <strong>Dormant Client Follow-Up</strong>
                <p style="font-size: 0.82rem; margin: 2px 0 0;">Pooja Sethi has not renewed her weekly box in 3 weeks.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="dash-grid-equal" style="margin-top: 24px;">
        <div class="panel" style="margin-bottom: 0;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <h3 style="font-size: 1.08rem; margin: 0;">Recent Bookings &amp; Upcoming</h3>
            <button type="button" class="btn btn--ghost btn--sm" data-jump-tab="bookings">Manage All</button>
          </div>
          ${state.bookings
            .slice(0, 4)
            .map(
              (b) => `
            <div class="service-item">
              <div>
                <div style="font-weight: 600; font-size: 0.92rem;">${escapeHtml(b.customer)} · ${escapeHtml(b.service)}</div>
                <div style="font-size: 0.78rem; color: var(--indigo-55);">${escapeHtml(b.date)} at ${escapeHtml(b.time)}</div>
              </div>
              <span class="status-text ${b.status === 'Confirmed' ? 'status-text--success' : b.status === 'Pending' ? 'status-text--warning' : 'status-text--indigo'}">
                ${escapeHtml(b.status)}
              </span>
            </div>
          `
            )
            .join('')}
        </div>

        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.08rem; margin-bottom: 12px;">Pending Payments &amp; Recent Reviews</h3>
          ${state.invoices
            .filter((i) => i.status === 'Pending')
            .map(
              (inv) => `
            <div class="service-item">
              <div>
                <div style="font-weight: 600; font-size: 0.92rem;">${escapeHtml(inv.customer)} (${escapeHtml(inv.id)})</div>
                <div style="font-size: 0.78rem; color: var(--indigo-55);">${escapeHtml(inv.service)}</div>
              </div>
              <strong class="tabular-nums" style="color: var(--warning);">₹${inv.amount}</strong>
            </div>
          `
            )
            .join('')}
          <div style="margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--indigo-08);">
            <div style="font-size: 0.82rem; font-weight: 600; color: var(--indigo);">Latest Review · Ankit Verma (5.0 ★)</div>
            <p style="font-size: 0.85rem; margin: 4px 0 0;">"Light, zero-excess-oil home meals just like home. Been subscribing for 4 months."</p>
          </div>
        </div>
      </div>
    `;

    document.getElementById('dash-view-live-store')?.addEventListener('click', () => {
      switchView('storefront', { storeId: 'meena-kitchen' });
    });
    document.getElementById('dash-quick-invoice')?.addEventListener('click', () => {
      state.activeDashTab = 'payments';
      saveState();
      renderDashboard();
    });
    main.querySelectorAll('[data-jump-tab]').forEach((b) => {
      b.addEventListener('click', () => {
        state.activeDashTab = b.getAttribute('data-jump-tab');
        saveState();
        renderDashboard();
      });
    });

    const ctx = document.getElementById('chart-overview-rev');
    if (ctx && typeof window.Chart === 'function') {
      overviewChartInstance = new window.Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'],
          datasets: [
            {
              label: 'Monthly Business Inflows (₹)',
              data: [31200, 34800, 36500, 41000, 44900, totalRevenue],
              borderColor: '#e47b61',
              backgroundColor: 'rgba(228, 123, 97, 0.14)',
              borderWidth: 3,
              fill: true,
              tension: 0.35,
              pointBackgroundColor: '#2c2e4d',
              pointRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: {
              beginAtZero: false,
              ticks: { callback: (v) => '₹' + Number(v).toLocaleString('en-IN') }
            }
          }
        }
      });
    }
  } else if (tab === 'profile') {
    const filledFields = [
      profile.businessName,
      profile.ownerName,
      profile.category,
      profile.location,
      profile.phone,
      profile.hours,
      profile.description
    ].filter((x) => x && x.trim().length > 0).length;
    const completion = Math.round((filledFields / 7) * 100);

    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">My DukaanID Profile</h1>
          <p style="margin: 0;">Update your verified digital identity details shown to customers and partners.</p>
        </div>
        <span class="status-text status-text--success"><i data-lucide="badge-check"></i> Verified Identity · ${completion}% Complete</span>
      </div>

      <div class="panel">
        <div class="progress-track" style="margin-bottom: 22px;">
          <div class="progress-fill" style="width: ${completion}%;"></div>
        </div>
        <form id="form-edit-profile" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div>
            <label for="prof-biz" class="field-label">Business Name</label>
            <input type="text" id="prof-biz" class="input" value="${escapeHtml(profile.businessName)}" />
          </div>
          <div>
            <label for="prof-owner" class="field-label">Owner Name</label>
            <input type="text" id="prof-owner" class="input" value="${escapeHtml(profile.ownerName)}" />
          </div>
          <div>
            <label for="prof-cat" class="field-label">Business Category</label>
            <input type="text" id="prof-cat" class="input" value="${escapeHtml(profile.category)}" />
          </div>
          <div>
            <label for="prof-loc" class="field-label">Location</label>
            <input type="text" id="prof-loc" class="input" value="${escapeHtml(profile.location)}" />
          </div>
          <div>
            <label for="prof-phone" class="field-label">Contact Mobile</label>
            <input type="text" id="prof-phone" class="input" value="${escapeHtml(profile.phone)}" />
          </div>
          <div>
            <label for="prof-hours" class="field-label">Business Hours</label>
            <input type="text" id="prof-hours" class="input" value="${escapeHtml(profile.hours)}" />
          </div>
          <div style="grid-column: 1 / -1;">
            <label for="prof-desc" class="field-label">Business Description</label>
            <textarea id="prof-desc" class="textarea">${escapeHtml(profile.description)}</textarea>
          </div>
          <div style="grid-column: 1 / -1; display: flex; justify-content: flex-end;">
            <button type="submit" class="btn btn--primary">Save DukaanID Profile</button>
          </div>
        </form>
      </div>
    `;

    document.getElementById('form-edit-profile')?.addEventListener('submit', (e) => {
      e.preventDefault();
      profile.businessName = document.getElementById('prof-biz').value.trim();
      profile.ownerName = document.getElementById('prof-owner').value.trim();
      profile.category = document.getElementById('prof-cat').value.trim();
      profile.location = document.getElementById('prof-loc').value.trim();
      profile.phone = document.getElementById('prof-phone').value.trim();
      profile.hours = document.getElementById('prof-hours').value.trim();
      profile.description = document.getElementById('prof-desc').value.trim();
      saveState();
      renderDashboard();
      showToast('DukaanID profile saved to LocalStorage.');
    });
  } else if (tab === 'storefront') {
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">My Smart Storefront</h1>
          <p style="margin: 0;">Share your QR storefront card and manage listed services.</p>
        </div>
        <button type="button" class="btn btn--primary" id="dash-open-public-store">Open Public Storefront</button>
      </div>

      <div class="dash-grid-equal">
        <div class="panel">
          <h3 style="font-size: 1.1rem; margin-bottom: 14px;">Printable QR Storefront Card</h3>
          <div style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap;">
            <div style="padding: 14px; background: var(--bg-cream); border: 1px solid var(--indigo-12); border-radius: 14px;">
              ${generateQrSvg('meena-kitchen', 124)}
            </div>
            <div>
              <h4 style="margin-bottom: 4px;">${escapeHtml(profile.businessName)}</h4>
              <p style="font-size: 0.88rem; margin-bottom: 10px;">${escapeHtml(profile.location)}</p>
              <div class="mono" style="font-size: 0.84rem; color: var(--coral); margin-bottom: 12px;">dukaanid.in/meena-kitchen</div>
              <button type="button" class="btn btn--secondary btn--sm" id="btn-dash-copy-link">Copy Storefront Link</button>
            </div>
          </div>
        </div>

        <div class="panel">
          <h3 style="font-size: 1.1rem; margin-bottom: 14px;">Active Service Catalogue</h3>
          ${profile.services
            .map(
              (s) => `
            <div class="service-item">
              <span>${escapeHtml(s.name)}</span>
              <strong class="tabular-nums">₹${s.price}</strong>
            </div>
          `
            )
            .join('')}
        </div>
      </div>
    `;
    document.getElementById('dash-open-public-store')?.addEventListener('click', () => {
      switchView('storefront', { storeId: 'meena-kitchen' });
    });
    document.getElementById('btn-dash-copy-link')?.addEventListener('click', () => {
      navigator.clipboard?.writeText(buildStoreUrl('meena-kitchen')).catch(() => {});
      showToast('Storefront link copied.');
    });
  } else if (tab === 'assistants') {
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">AI Business Assistants</h1>
          <p style="margin: 0;">Review AI-drafted customer replies, reminders and pricing insights before they go live.</p>
        </div>
        <button type="button" class="btn btn--secondary btn--sm" id="dash-open-ai-showcase">Explore All 6 Agent Demos</button>
      </div>

      <div class="dash-grid-equal">
        <div class="panel">
          <h3 style="font-size: 1.1rem; margin-bottom: 10px;">Customer Agent · Approval Queue</h3>
          <p style="font-size: 0.88rem;">Draft reply prepared for <strong>Ankit Verma</strong> (Weekly Office Tiffin renewal):</p>
          <div class="notice-box" style="margin-bottom: 14px;">
            "Namaste Ankit ji! Your 5-meal veg tiffin pack for next week is ready to schedule at ₹550. Confirm to lock your 12:30 PM slot."
          </div>
          <div style="display: flex; gap: 10px;">
            <button type="button" class="btn btn--success btn--sm" id="btn-dash-ai-approve">Approve &amp; Send</button>
            <button type="button" class="btn btn--secondary btn--sm" id="btn-dash-ai-dismiss">Edit Later</button>
          </div>
        </div>

        <div class="panel">
          <h3 style="font-size: 1.1rem; margin-bottom: 10px;">Operations Agent · Smart Reminders</h3>
          <ul style="padding-left: 18px; margin: 0; font-size: 0.9rem; color: var(--indigo-70);">
            <li style="margin-bottom: 8px;">Order extra 50 eco-friendly tiffin containers before Friday.</li>
            <li style="margin-bottom: 8px;">Send polite payment reminder for INV-2041 (₹1,850).</li>
            <li>Update Sunday catering availability on storefront.</li>
          </ul>
        </div>
      </div>
    `;
    document.getElementById('dash-open-ai-showcase')?.addEventListener('click', () => {
      switchView('landing', { scrollTo: 'ai-agents' });
    });
    document.getElementById('btn-dash-ai-approve')?.addEventListener('click', () => {
      showToast('AI draft approved and queued for customer delivery.');
    });
    document.getElementById('btn-dash-ai-dismiss')?.addEventListener('click', () => {
      showToast('Draft saved for manual editing.');
    });
  } else if (tab === 'bookings') {
    const filterStatus = state.dashBookingFilter || 'All';
    const rows = state.bookings.filter((b) => filterStatus === 'All' || b.status === filterStatus);

    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">Bookings Management</h1>
          <p style="margin: 0;">Accept, reject or mark customer bookings completed.</p>
        </div>
      </div>

      <div class="category-bar">
        ${['All', 'Pending', 'Confirmed', 'Completed', 'Cancelled']
          .map(
            (st) => `
          <button type="button" class="filter-tab ${filterStatus === st ? 'is-active' : ''}" data-bk-filter="${st}">${st}</button>
        `
          )
          .join('')}
      </div>

      <div class="panel data-table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Customer</th>
              <th>Service</th>
              <th>Schedule</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${
              rows.length === 0
                ? `<tr><td colspan="7" style="text-align: center; padding: 28px;">No bookings in ${escapeHtml(filterStatus)} status.</td></tr>`
                : rows
                    .map(
                      (b) => `
              <tr>
                <td class="mono">${escapeHtml(b.id)}</td>
                <td><strong>${escapeHtml(b.customer)}</strong><br/><span style="font-size: 0.78rem; color: var(--indigo-55);">${escapeHtml(b.phone)}</span></td>
                <td>${escapeHtml(b.service)}</td>
                <td>${escapeHtml(b.date)} · ${escapeHtml(b.time)}</td>
                <td class="tabular-nums"><strong>₹${b.amount}</strong></td>
                <td><span class="status-text ${
                  b.status === 'Confirmed' || b.status === 'Completed'
                    ? 'status-text--success'
                    : b.status === 'Pending'
                      ? 'status-text--warning'
                      : 'status-text--danger'
                }">${escapeHtml(b.status)}</span></td>
                <td>
                  <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                    ${
                      b.status === 'Pending'
                        ? `<button type="button" class="btn btn--success btn--sm" data-bk-action="Confirmed" data-bk-id="${escapeHtml(b.id)}">Accept</button>
                           <button type="button" class="btn btn--danger-outline btn--sm" data-bk-action="Cancelled" data-bk-id="${escapeHtml(b.id)}">Reject</button>`
                        : ''
                    }
                    ${
                      b.status === 'Confirmed'
                        ? `<button type="button" class="btn btn--indigo btn--sm" data-bk-action="Completed" data-bk-id="${escapeHtml(b.id)}">Mark Completed</button>`
                        : ''
                    }
                    ${b.status === 'Completed' || b.status === 'Cancelled' ? '<span style="font-size: 0.8rem; color: var(--indigo-55);">Archived</span>' : ''}
                  </div>
                </td>
              </tr>
            `
                    )
                    .join('')
            }
          </tbody>
        </table>
      </div>
    `;

    main.querySelectorAll('[data-bk-filter]').forEach((b) => {
      b.addEventListener('click', () => {
        state.dashBookingFilter = b.getAttribute('data-bk-filter');
        renderDashboard();
      });
    });

    main.querySelectorAll('[data-bk-action]').forEach((b) => {
      b.addEventListener('click', () => {
        const id = b.getAttribute('data-bk-id');
        const nextStatus = b.getAttribute('data-bk-action');
        const item = state.bookings.find((x) => x.id === id);
        if (item) {
          item.status = nextStatus;
          if (nextStatus === 'Completed') {
            const kitchen = state.businesses.find(x => x.id === 'meena-kitchen');
            if (kitchen) kitchen.completedJobs = (kitchen.completedJobs || 0) + 1;
            const invoiceExists = state.invoices.some(inv => inv.bookingId === id);
            if (!invoiceExists) state.invoices.unshift({ id: 'INV-' + Date.now().toString().slice(-6), bookingId: id, customer: item.customer, service: item.service, date: new Date().toLocaleDateString('en-IN'), amount: Number(item.amount) || 0, status: 'Pending' });
            logActivity('Job marked completed', `${item.service} for ${item.customer}. A pending invoice was added to Payments.`, 'Reputation');
          } else {
            logActivity(`Booking ${nextStatus.toLowerCase()}`, `${item.customer} · ${item.service} · ${id}`, 'Operations');
          }
          saveState();
          renderDashboard();
          showToast(nextStatus === 'Completed' ? `Job completed. A linked invoice was created for ${id}.` : `Booking ${id} marked ${nextStatus}.`);
        }
      });
    });
  } else if (tab === 'customers') {
    const q = (state.dashCustQuery || '').toLowerCase();
    const tag = state.dashCustTag || 'All';
    const list = state.customers.filter((c) => {
      const matchQ = !q || c.name.toLowerCase().includes(q) || c.phone.includes(q);
      const matchTag = tag === 'All' || c.tag === tag;
      return matchQ && matchTag;
    });

    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">Customer Directory</h1>
          <p style="margin: 0;">Track repeat buyers, order history and follow-up opportunities.</p>
        </div>
      </div>

      <div style="display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px;">
        <input type="search" id="cust-search" class="input" style="max-width: 320px;" placeholder="Search customer name or phone..." value="${escapeHtml(state.dashCustQuery || '')}" />
        <div style="display: flex; gap: 6px;">
          ${['All', 'Repeat', 'Active', 'Follow-up']
            .map((t) => `<button type="button" class="filter-tab ${tag === t ? 'is-active' : ''}" data-cust-tag="${t}">${t}</button>`)
            .join('')}
        </div>
      </div>

      <div class="panel data-table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Contact</th>
              <th>Orders</th>
              <th>Last Interaction</th>
              <th>Total Purchases</th>
              <th>Segment</th>
            </tr>
          </thead>
          <tbody>
            ${list
              .map(
                (c) => `
              <tr>
                <td><strong>${escapeHtml(c.name)}</strong></td>
                <td class="mono">${escapeHtml(c.phone)}</td>
                <td class="tabular-nums">${c.orders}</td>
                <td>${escapeHtml(c.lastSeen)}</td>
                <td class="tabular-nums"><strong>₹${c.spent.toLocaleString('en-IN')}</strong></td>
                <td><span class="status-text status-text--indigo">${escapeHtml(c.tag)}</span></td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>
      </div>
    `;

    document.getElementById('cust-search')?.addEventListener('input', (e) => {
      state.dashCustQuery = e.target.value;
      renderDashboardTabContent('customers');
    });
    main.querySelectorAll('[data-cust-tag]').forEach((b) => {
      b.addEventListener('click', () => {
        state.dashCustTag = b.getAttribute('data-cust-tag');
        renderDashboardTabContent('customers');
      });
    });
  } else if (tab === 'reputation') {
    const kitchen = state.businesses.find((b) => b.id === 'meena-kitchen') || state.businesses[1];
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">Reputation Wallet</h1>
          <p style="margin: 0;">Your portable proof of verified work, ratings and customer trust.</p>
        </div>
        <button type="button" class="btn btn--primary btn--sm" id="btn-share-rep">Share Reputation Profile</button>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-card__label">Total Completed Jobs</div>
          <div class="kpi-card__value tabular-nums">${kitchen.completedJobs}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Average Rating</div>
          <div class="kpi-card__value tabular-nums">${kitchen.rating.toFixed(1)} ★</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Repeat Customers</div>
          <div class="kpi-card__value tabular-nums">${kitchen.repeatRate}%</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Verified Referrals</div>
          <div class="kpi-card__value tabular-nums">41</div>
        </div>
      </div>

      <div class="dash-grid-equal">
        <div class="panel">
          <h3 style="font-size: 1.1rem; margin-bottom: 12px;">Verified Reviews</h3>
          ${kitchen.reviews
            .map(
              (r) => `
            <div class="review-item">
              <div style="display: flex; justify-content: space-between;">
                <strong>${escapeHtml(r.author)}</strong>
                <span style="color: var(--coral); font-weight: 700;">${r.rating}.0 ★</span>
              </div>
              <p style="margin: 4px 0;">"${escapeHtml(r.text)}"</p>
              <span style="font-size: 0.78rem; color: var(--indigo-55);">${escapeHtml(r.date)}</span>
            </div>
          `
            )
            .join('')}
        </div>

        <div class="panel">
          <h3 style="font-size: 1.1rem; margin-bottom: 12px;">Service History Timeline</h3>
          <div class="kv-list">
            <div class="kv-row"><span class="kv-key">Nov 2026</span><span class="kv-val">28 Tiffin &amp; Catering Orders Verified</span></div>
            <div class="kv-row"><span class="kv-key">Oct 2026</span><span class="kv-val">64 Festive &amp; Daily Meals Delivered</span></div>
            <div class="kv-row"><span class="kv-key">Sep 2026</span><span class="kv-val">59 Repeat Subscriptions Completed</span></div>
            <div class="kv-row"><span class="kv-key">Aug 2026</span><span class="kv-val">Hygiene &amp; Kitchen Profile Verified</span></div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btn-share-rep')?.addEventListener('click', () => {
      openModal(
        'Share Portable Reputation Wallet',
        `
          <p>Share your verified Reputation Wallet link with new apartment societies, corporate offices or partners.</p>
          <div class="notice-box" style="margin-bottom: 14px;">
            <strong>${escapeHtml(profile.businessName)}</strong><br/>
            312 Verified Jobs · 4.9 ★ Rating · 76% Repeat Customers
          </div>
          <button type="button" class="btn btn--primary" id="btn-copy-rep-link">Copy Verified Reputation Link</button>
        `
      );
      document.getElementById('btn-copy-rep-link')?.addEventListener('click', () => {
        navigator.clipboard?.writeText(`${window.location.origin}${window.location.pathname}?view=reputation`).catch(() => {});
        showToast('Reputation profile link copied.');
        closeModal();
      });
    });
  } else if (tab === 'payments') {
    const paidSum = state.invoices.filter((i) => i.status === 'Paid').reduce((a, b) => a + b.amount, 0);
    const pendingSum = state.invoices.filter((i) => i.status === 'Pending').reduce((a, b) => a + b.amount, 0);

    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">Payments &amp; Invoices</h1>
          <p style="margin: 0;">Generate clean GST/non-GST bills, download PDFs and send polite reminders.</p>
        </div>
        <button type="button" class="btn btn--primary btn--sm" id="btn-new-invoice">+ Generate Invoice</button>
      </div>

      <div class="kpi-grid" style="grid-template-columns: repeat(3, 1fr);">
        <div class="kpi-card">
          <div class="kpi-card__label">Total Tracked Revenue</div>
          <div class="kpi-card__value tabular-nums">₹${(paidSum + 42800).toLocaleString('en-IN')}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Completed Payments (Recent)</div>
          <div class="kpi-card__value tabular-nums" style="color: var(--success);">₹${paidSum.toLocaleString('en-IN')}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Pending Payments</div>
          <div class="kpi-card__value tabular-nums" style="color: var(--warning);">₹${pendingSum.toLocaleString('en-IN')}</div>
        </div>
      </div>

      <div class="panel data-table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Invoice ID</th>
              <th>Customer</th>
              <th>Service</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${state.invoices
              .map(
                (inv) => `
              <tr>
                <td class="mono">${escapeHtml(inv.id)}</td>
                <td><strong>${escapeHtml(inv.customer)}</strong></td>
                <td>${escapeHtml(inv.service)}</td>
                <td>${escapeHtml(inv.date)}</td>
                <td class="tabular-nums"><strong>₹${inv.amount}</strong></td>
                <td><span class="status-text ${inv.status === 'Paid' ? 'status-text--success' : 'status-text--warning'}">${escapeHtml(inv.status)}</span></td>
                <td>
                  <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                    <button type="button" class="btn btn--secondary btn--sm" data-dl-inv="${escapeHtml(inv.id)}">Download</button>
                    ${
                      inv.status === 'Pending'
                        ? `<button type="button" class="btn btn--primary btn--sm" data-remind-inv="${escapeHtml(inv.id)}">Send Reminder</button>
                           <button type="button" class="btn btn--success btn--sm" data-mark-paid="${escapeHtml(inv.id)}">Mark Paid</button>`
                        : ''
                    }
                  </div>
                </td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>
      </div>
    `;

    document.getElementById('btn-new-invoice')?.addEventListener('click', () => {
      openModal(
        'Generate New Invoice',
        `
          <form id="form-gen-inv" style="display: grid; gap: 12px;">
            <div>
              <label for="inv-cust" class="field-label">Customer Name</label>
              <input type="text" id="inv-cust" class="input" required placeholder="e.g. Ritu Sharma" />
            </div>
            <div>
              <label for="inv-srv" class="field-label">Service / Item</label>
              <input type="text" id="inv-srv" class="input" required placeholder="e.g. Weekly Veg Tiffin (5 Meals)" />
            </div>
            <div>
              <label for="inv-amt" class="field-label">Amount (₹)</label>
              <input type="number" id="inv-amt" class="input tabular-nums" required min="50" value="550" />
            </div>
            <button type="submit" class="btn btn--primary">Create Invoice</button>
          </form>
        `
      );
      document.getElementById('form-gen-inv')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const newInv = {
          id: 'INV-' + Math.floor(2042 + Math.random() * 50),
          customer: document.getElementById('inv-cust').value.trim(),
          service: document.getElementById('inv-srv').value.trim(),
          date: '13 Nov 2026',
          amount: Number(document.getElementById('inv-amt').value) || 550,
          status: 'Pending'
        };
        state.invoices.unshift(newInv);
        saveState();
        closeModal();
        renderDashboard();
        showToast(`Invoice ${newInv.id} created.`);
      });
    });

    main.querySelectorAll('[data-dl-inv]').forEach((b) => {
      b.addEventListener('click', () => {
        const inv = state.invoices.find((x) => x.id === b.getAttribute('data-dl-inv'));
        if (!inv) return;
        const text = `DUKAANID INVOICE RECEIPT\nInvoice: ${inv.id}\nBusiness: ${profile.businessName} (${profile.id})\nCustomer: ${inv.customer}\nService: ${inv.service}\nDate: ${inv.date}\nAmount: INR ${inv.amount}\nStatus: ${inv.status}\n`;
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${inv.id}.txt`;
        a.click();
        URL.revokeObjectURL(url);
        showToast(`Downloaded invoice ${inv.id}.`);
      });
    });

    main.querySelectorAll('[data-remind-inv]').forEach((b) => {
      b.addEventListener('click', () => {
        openModal('WhatsApp Reminder Preview', `<p>This is a demo message. No WhatsApp message has been sent.</p><div class="notice-box"><strong>Namaste!</strong><br/>A gentle reminder that invoice ${escapeHtml(b.getAttribute('data-remind-inv'))} is pending. Please let us know if you need the invoice again.</div><button type="button" class="btn btn--primary" id="btn-close-reminder-preview">Done</button>`);
        document.getElementById('btn-close-reminder-preview')?.addEventListener('click', closeModal);
      });
    });

    main.querySelectorAll('[data-mark-paid]').forEach((b) => {
      b.addEventListener('click', () => {
        const inv = state.invoices.find((x) => x.id === b.getAttribute('data-mark-paid'));
        if (inv) {
          inv.status = 'Paid';
          logActivity('Invoice payment recorded', `${inv.id} · ₹${inv.amount} received from ${inv.customer} (demo record).`, 'Operations');
          saveState();
          renderDashboard();
          showToast(`Payment recorded for ${inv.id}.`);
        }
      });
    });
  } else if (tab === 'credit') {
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">Credit-Readiness Passport</h1>
          <p style="margin: 0;">Structured business transaction profile prepared for consent-based sharing.</p>
        </div>
        <button type="button" class="btn btn--primary" id="btn-dash-gen-passport">Generate My Credit Passport</button>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-card__label">Tracked Paid Invoices</div>
          <div class="kpi-card__value tabular-nums">₹${state.invoices.filter(i => i.status === 'Paid').reduce((sum, i) => sum + Number(i.amount || 0), 0).toLocaleString('en-IN')}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Payment Consistency</div>
          <div class="kpi-card__value">High</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Repeat Customer Ratio</div>
          <div class="kpi-card__value tabular-nums">${state.businesses.find(b => b.id === 'meena-kitchen')?.repeatRate || 0}%</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-card__label">Record Completeness</div>
          <div class="kpi-card__value tabular-nums">${Math.min(100, Math.round((state.invoices.length + state.bookings.length) / 10 * 100))}%</div>
        </div>
      </div>

      <div class="dash-grid-2">
        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem; margin-bottom: 14px;">Monthly Income Consistency Trend</h3>
          <div class="chart-box"><canvas id="chart-credit-trend"></canvas></div>
        </div>

        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem; margin-bottom: 12px;">Business Activity Summary</h3>
          <div class="kv-list" style="margin-bottom: 16px;">
            <div class="kv-row"><span class="kv-key">Active Months</span><span class="kv-val">6 Consecutive Months</span></div>
            <div class="kv-row"><span class="kv-key">Paid Invoices</span><span class="kv-val tabular-nums">${state.invoices.filter(i => i.status === 'Paid').length}</span></div>
            <div class="kv-row"><span class="kv-key">Average Paid Invoice</span><span class="kv-val tabular-nums">₹${Math.round(state.invoices.filter(i => i.status === 'Paid').reduce((sum, i) => sum + Number(i.amount || 0), 0) / Math.max(1, state.invoices.filter(i => i.status === 'Paid').length)).toLocaleString('en-IN')}</span></div>
            <div class="kv-row"><span class="kv-key">Consent Status</span><span class="kv-val">${state.agentDemo.creditConsentGranted ? 'Shared with Consent' : 'Private (Not Shared)'}</span></div>
          </div>
          <div class="notice-box">
            <strong>Disclaimer:</strong> This passport is a structured credit-readiness summary of recorded business activity—not a credit score, loan guarantee or lending decision.
          </div>
        </div>
      </div>
    `;

    document.getElementById('btn-dash-gen-passport')?.addEventListener('click', () => {
      openCreditPassportModal();
    });

    const cCtx = document.getElementById('chart-credit-trend');
    if (cCtx && typeof window.Chart === 'function') {
      creditChartInstance = new window.Chart(cCtx, {
        type: 'bar',
        data: {
          labels: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'],
          datasets: [
            {
              label: 'Verified Monthly Inflows (₹)',
              data: [31200, 34800, 36500, 41000, 44900, 48500],
              backgroundColor: ['#b0a2cb', '#b0a2cb', '#aca1c9', '#aca1c9', '#2c2e4d', '#e47b61'],
              borderRadius: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: {
              beginAtZero: true,
              ticks: { callback: (v) => '₹' + Number(v).toLocaleString('en-IN') }
            }
          }
        }
      });
    }
  } else if (tab === 'growth') {
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">AI Growth Insights</h1>
          <p style="margin: 0;">Actionable suggestions derived from your sample booking and customer activity.</p>
        </div>
      </div>

      <div class="problem-grid">
        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem;">Weekend Bookings Are Increasing</h3>
          <p>Saturday family meal orders increased by 30% over the past month. Consider publishing a dedicated Saturday Family Thali slot.</p>
          <button type="button" class="btn btn--secondary btn--sm" data-growth-act="Added Saturday Thali Highlight">Apply to Storefront</button>
        </div>
        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem;">Promote Your Most Popular Service</h3>
          <p>Weekly Office Tiffin generates 54% of repeat orders. Share a WhatsApp status card for nearby offices.</p>
          <button type="button" class="btn btn--secondary btn--sm" data-growth-act="Prepared WhatsApp Promo Card">Generate Promo Card</button>
        </div>
        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem;">Follow Up With Inactive Clients</h3>
          <p>3 previous tiffin customers have not booked in the last 21 days. Send a festive comeback offer.</p>
          <button type="button" class="btn btn--secondary btn--sm" data-growth-act="Queued 3 polite follow-ups">Draft Follow-ups</button>
        </div>
        <div class="panel" style="margin-bottom: 0;">
          <h3 style="font-size: 1.1rem;">Review Demand-Based Pricing</h3>
          <p>Your Special Paneer Box is rated 5.0 ★. Increasing price from ₹220 to ₹240 aligns with local demand.</p>
          <button type="button" class="btn btn--secondary btn--sm" data-growth-act="Saved pricing recommendation">Review Pricing</button>
        </div>
      </div>
    `;
    main.querySelectorAll('[data-growth-act]').forEach((b) => {
      b.addEventListener('click', () => showToast(b.getAttribute('data-growth-act') + ' (prototype simulation).'));
    });
  } else if (tab === 'settings') {
    main.innerHTML = `
      <div class="dash-topbar">
        <div>
          <h1 style="font-size: 1.75rem; margin-bottom: 4px;">Settings &amp; Demo Controls</h1>
          <p style="margin: 0;">Manage language preferences, data consent and prototype LocalStorage state.</p>
        </div>
      </div>

      <div class="panel" style="max-width: 680px;">
        <div class="service-item">
          <div>
            <strong>Interface Language</strong>
            <div style="font-size: 0.84rem; color: var(--indigo-55);">Switch public and navigation text between English and Hindi.</div>
          </div>
          <div style="display: flex; gap: 8px;">
            <button type="button" class="btn btn--secondary btn--sm" id="set-lang-en">English</button>
            <button type="button" class="btn btn--secondary btn--sm" id="set-lang-hi">हिंदी</button>
          </div>
        </div>
        <div class="service-item">
          <div>
            <strong>Reset Prototype Demo Data</strong>
            <div style="font-size: 0.84rem; color: var(--indigo-55);">Restore all sample businesses, bookings and invoices to their initial state.</div>
          </div>
          <button type="button" class="btn btn--danger-outline btn--sm" id="btn-reset-all-demo">Reset Demo Data</button>
        </div>
      </div>
    `;
    document.getElementById('set-lang-en')?.addEventListener('click', () => {
      applyLanguage('en');
      showToast('Language set to English.');
    });
    document.getElementById('set-lang-hi')?.addEventListener('click', () => {
      applyLanguage('hi');
      showToast('भाषा हिंदी पर सेट की गई।');
    });
    document.getElementById('btn-reset-all-demo')?.addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEY);
      state = getInitialState();
      applyLanguage(state.lang);
      renderExploreMarketplace();
      renderAgentCards();
      renderAgentWorkbench();
      renderDashboard();
      showToast('Prototype demo data restored.');
    });
  }
}

/* ==========================================================================
   Credit Passport Modal (with Explicit Consent Screen)
   ========================================================================== */
function openCreditPassportModal() {
  logActivity('Credit-readiness passport preview generated', 'The report was compiled from the current demo invoice and booking records.', 'Credit');
  const profile = state.workerProfile;
  const paidInvoices = state.invoices.filter(inv => inv.status === 'Paid');
  const paidTotal = paidInvoices.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
  const completedCount = state.bookings.filter(b => b.status === 'Completed').length;
  const repeatRatio = state.businesses.find(b => b.id === 'meena-kitchen')?.repeatRate || 0;
  openModal(
    'Credit-Readiness Passport Preview',
    `
      <div class="passport-doc">
        <div class="passport-doc__header">
          <div>
            <div style="font-size: 0.76rem; font-weight: 700; color: var(--coral);">DUKAANID CREDIT-READINESS PASSPORT</div>
            <h3 style="margin: 4px 0;">${escapeHtml(profile.businessName)}</h3>
            <div class="mono" style="font-size: 0.8rem; color: var(--indigo-55);">ID: ${escapeHtml(profile.id)} · ${escapeHtml(profile.location)}</div>
          </div>
          <div>${generateQrSvg(profile.id, 66)}</div>
        </div>

        <div class="kv-list" style="margin-bottom: 16px;">
          <div class="kv-row"><span class="kv-key">6-Month Verified Inflows</span><span class="kv-val tabular-nums">₹${paidTotal.toLocaleString('en-IN')}</span></div>
          <div class="kv-row"><span class="kv-key">Completed Jobs</span><span class="kv-val tabular-nums">${completedCount}</span></div>
          <div class="kv-row"><span class="kv-key">Paid Invoices</span><span class="kv-val tabular-nums">${paidInvoices.length}</span></div>
          <div class="kv-row"><span class="kv-key">Repeat Customer Ratio</span><span class="kv-val tabular-nums">${repeatRatio}%</span></div>
          <div class="kv-row"><span class="kv-key">Income Consistency</span><span class="kv-val" style="color: var(--success);">Steady (6/6 Months Active)</span></div>
          <div class="kv-row"><span class="kv-key">Record Completeness</span><span class="kv-val tabular-nums">92%</span></div>
        </div>

        <div class="notice-box" style="margin-bottom: 18px;">
          <strong>Important Notice:</strong> This is a credit-readiness summary compiled from self-recorded and platform-verified business activity. It is <strong>not</strong> a guaranteed credit score, loan approval or lending decision.
        </div>

        <div style="padding: 14px; background: var(--bg-surface); border: 1px solid var(--indigo-12); border-radius: var(--radius-md);">
          <label style="display: flex; align-items: flex-start; gap: 10px; font-size: 0.88rem; cursor: pointer; margin-bottom: 12px;">
            <input type="checkbox" id="chk-credit-consent" ${state.agentDemo.creditConsentGranted ? 'checked' : ''} style="margin-top: 3px;" />
            <span>I explicitly consent to share this structured business activity summary with selected micro-lending partners for credit assessment.</span>
          </label>
          <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button type="button" class="btn btn--primary btn--sm" id="btn-share-lender-sim">Share With Explicit Consent</button>
            <button type="button" class="btn btn--secondary btn--sm" id="btn-dl-passport">Download Summary</button>
          </div>
        </div>
      </div>
    `
  );

  document.getElementById('btn-share-lender-sim')?.addEventListener('click', () => {
    const chk = document.getElementById('chk-credit-consent');
    if (!chk?.checked) {
      showToast('Please check the explicit consent box before sharing.');
      return;
    }
    state.agentDemo.creditConsentGranted = true;
    saveState();
    closeModal();
    if (state.activeView === 'dashboard') renderDashboard();
    showToast('Consent recorded. Simulated Credit-Readiness Passport shared securely.');
  });

  document.getElementById('btn-dl-passport')?.addEventListener('click', () => {
    const text = `DUKAANID CREDIT-READINESS PASSPORT\nBusiness: ${profile.businessName} (${profile.id})\nTracked paid invoices: INR ${paidTotal}\nPaid invoices: ${paidInvoices.length}\nCompleted jobs: ${completedCount}\nRepeat customer ratio: ${repeatRatio}%\nNote: Demo data summary only; not a credit score or loan decision.\n`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${profile.id}-credit-passport.txt`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Credit-Readiness Passport summary downloaded.');
  });
}

/* ==========================================================================
   Floating AI Business Assistant Modal
   ========================================================================== */
function openFloatingAiModal() {
  openModal(
    'DukaanID AI Business Assistant',
    `
      <p style="font-size: 0.9rem;">Ask your AI team to draft a customer quote, summarise unpaid invoices or suggest a weekend offer.</p>
      <div class="preset-row">
        <button type="button" class="btn btn--secondary btn--sm" data-ai-prompt="Summarise my pending actions today">Today's Priorities</button>
        <button type="button" class="btn btn--secondary btn--sm" data-ai-prompt="Draft a WhatsApp payment reminder">Draft Payment Reminder</button>
        <button type="button" class="btn btn--secondary btn--sm" data-ai-prompt="How can I get more weekend bookings?">Weekend Growth Idea</button>
      </div>
      <div class="notice-box" id="floating-ai-reply" style="margin-bottom: 14px;">
        Namaste Meena ji! You have ${state.bookings.filter((b) => b.status === 'Pending').length} pending booking requests and 2 unpaid invoices. Ready whenever you need help.
      </div>
      <div style="display: flex; gap: 8px;">
        <input type="text" id="floating-ai-input" class="input" placeholder="Ask anything about your business..." />
        <button type="button" class="btn btn--primary btn--sm" id="floating-ai-send">Ask</button>
      </div>
    `
  );

  const handlePrompt = (promptText) => {
    const replyEl = document.getElementById('floating-ai-reply');
    if (!replyEl) return;
    const p = promptText.toLowerCase();
    if (p.includes('payment') || p.includes('reminder')) {
      replyEl.innerHTML =
        '<strong>Customer Agent Draft:</strong><br/>"Namaste! Just a gentle reminder regarding your pending DukaanID invoice. You can pay via UPI at your convenience. Thank you for supporting our kitchen!"';
    } else if (p.includes('weekend') || p.includes('booking')) {
      replyEl.innerHTML =
        '<strong>Growth Agent Suggestion:</strong><br/>Launch a "Sunday Special Family Thali (4 pax)" at ₹460 and share your QR storefront in 2 nearby housing society groups.';
    } else {
      replyEl.innerHTML = `<strong>Operations Summary:</strong><br/>1) Review ${state.bookings.filter((b) => b.status === 'Pending').length} pending bookings.<br/>2) Follow up on 2 pending invoices (₹2,290).<br/>3) Restock 50 meal boxes before Friday.`;
    }
  };

  document.querySelectorAll('[data-ai-prompt]').forEach((b) => {
    b.addEventListener('click', () => handlePrompt(b.getAttribute('data-ai-prompt')));
  });
  document.getElementById('floating-ai-send')?.addEventListener('click', () => {
    const val = document.getElementById('floating-ai-input')?.value?.trim();
    if (val) handlePrompt(val);
  });
}

/* ==========================================================================
   Login Modal & Info/Legal Modals
   ========================================================================== */
function openLoginModal() {
  openModal(
    'Login to Worker Dashboard',
    `
      <p style="font-size: 0.92rem;">Sign in to the interactive worker workspace as <strong>Meena Devi (Meena's Homemade Kitchen)</strong> or launch new worker onboarding.</p>
      <div style="display: grid; gap: 12px; margin-bottom: 18px;">
        <div>
          <label for="login-mobile" class="field-label">Registered Mobile Number (Demo)</label>
          <input type="tel" id="login-mobile" class="input mono" value="+91 98712 55410" />
        </div>
      </div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <button type="button" class="btn btn--primary" id="btn-confirm-demo-login">Enter Worker Dashboard</button>
        <button type="button" class="btn btn--secondary" id="btn-login-to-onboard">Create New DukaanID</button>
      </div>
    `
  );
  document.getElementById('btn-confirm-demo-login')?.addEventListener('click', () => {
    closeModal();
    switchView('dashboard', { dashTab: 'overview' });
    showToast("Logged into Meena's Homemade Kitchen dashboard.");
  });
  document.getElementById('btn-login-to-onboard')?.addEventListener('click', () => {
    closeModal();
    switchView('onboarding');
  });
}

function openInfoModal(key) {
  const topics = {
    contact: ['Contact DukaanID', '<p>Reach the DukaanID prototype team at <strong>hello@dukaanid.in</strong> for partnerships, community hubs or hackathon enquiries.</p>'],
    help: ['Help Centre', '<p>Need assistance setting up your DukaanID? Visit our 8-step guided setup or test the Onboarding Agent with a voice sample.</p>'],
    faq: ['Frequently Asked Questions', '<p><strong>Is DukaanID free?</strong> Yes, creating your digital identity, storefront and QR code is proposed at ₹0/month.</p><p><strong>Do lenders automatically see my income?</strong> Never. Financial summaries are shared only after your explicit consent.</p>'],
    privacy: ['Privacy Policy', '<p>DukaanID follows consent-first data principles. In this frontend prototype, all demo data remains strictly in your browser LocalStorage.</p>'],
    terms: ['Terms & Conditions', '<p>This is a hackathon and product prototype demonstrating digital identity, agentic workflows and credit-readiness tools for India’s informal workforce.</p>'],
    data: ['Data Protection', '<p>Worker financial logs and customer lists are structured with explicit user consent gates before any simulated third-party sharing.</p>'],
    linkedin: ['DukaanID on LinkedIn', '<p>Follow DukaanID updates on community onboarding pilots and ONDC ecosystem integrations.</p>'],
    instagram: ['DukaanID on Instagram', '<p>Discover stories of local tailors, artisans and home kitchens across India.</p>'],
    youtube: ['DukaanID Tutorials on YouTube', '<p>Watch 2-minute Hindi &amp; regional tutorials on setting up your QR storefront.</p>']
  };
  const [title, body] = topics[key] || ['DukaanID Information', '<p>Information dialog.</p>'];
  openModal(title, body);
}

/* ==========================================================================
   Scroll Reveal & Animated Counters
   ========================================================================== */
function initObservers() {
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const revObs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revObs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    revealEls.forEach((el) => revObs.observe(el));

    const statsStrip = document.getElementById('stats-strip');
    if (statsStrip) {
      const statObs = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              animateCounters();
              statObs.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.2 }
      );
      statObs.observe(statsStrip);
    }
  } else {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }
}

function animateCounters() {
  document.querySelectorAll('[data-count-target]').forEach((el) => {
    const target = Number(el.getAttribute('data-count-target'));
    const prefix = el.getAttribute('data-count-prefix') || '';
    const suffix = el.getAttribute('data-count-suffix') || '';
    const duration = 900;
    const start = performance.now();

    function tick(now) {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      const val = Math.round(target * eased);
      el.textContent = `${prefix}${val}${suffix}`;
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });
}

/* ==========================================================================
   Bootstrap & Event Wiring
   ========================================================================== */
function init() {
  // Deep-link support for QR storefronts generated by this prototype.
  const requestedStore = new URLSearchParams(window.location.search).get('store');
  if (requestedStore && state.businesses.some(b => b.id === requestedStore)) {
    state.activeStoreId = requestedStore;
    state.activeView = 'storefront';
  }
  // Hero Ecosystem visuals
  const heroImg = document.getElementById('hero-eco-img');
  if (heroImg) heroImg.src = imgTailor;
  const heroQr = document.getElementById('hero-qr-preview');
  if (heroQr) heroQr.innerHTML = generateQrSvg('aditi-tailoring', 48);

  // Navigation buttons
  document.querySelectorAll('[data-nav-view]').forEach((el) => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const view = el.getAttribute('data-nav-view');
      const scrollTo = el.getAttribute('data-scroll-to');
      const dashTab = el.getAttribute('data-dash-tab');
      switchView(view, { scrollTo, dashTab });
    });
  });

  // Topbar / Mobile / Hero CTAs
  document.getElementById('btn-nav-start')?.addEventListener('click', () => switchView('onboarding'));
  document.getElementById('btn-mobile-start')?.addEventListener('click', () => switchView('onboarding'));
  document.getElementById('btn-hero-create')?.addEventListener('click', () => switchView('onboarding'));
  document.getElementById('btn-hero-view-store')?.addEventListener('click', () =>
    switchView('storefront', { storeId: 'aditi-tailoring' })
  );

  document.getElementById('btn-nav-login')?.addEventListener('click', openLoginModal);
  document.getElementById('btn-mobile-login')?.addEventListener('click', openLoginModal);

  // Hamburger toggle
  const hamBtn = document.getElementById('btn-hamburger');
  const drawer = document.getElementById('mobile-drawer');
  hamBtn?.addEventListener('click', () => {
    const isOpen = drawer?.classList.toggle('is-open');
    hamBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  });

  // Language switcher
  document.querySelectorAll('.lang-btn').forEach((btn) => {
    btn.addEventListener('click', () => applyLanguage(btn.getAttribute('data-lang')));
  });

  // Agent pipeline & tabs
  document.querySelectorAll('[data-agent-select]').forEach((n) => {
    n.addEventListener('click', () => selectAgentTab(n.getAttribute('data-agent-select'), true));
  });
  document.querySelectorAll('[data-agent-tab]').forEach((t) => {
    t.addEventListener('click', () => selectAgentTab(t.getAttribute('data-agent-tab'), false));
  });

  // Explore controls
  document.getElementById('explore-search')?.addEventListener('input', (e) => {
    state.exploreFilter.search = e.target.value;
    renderExploreMarketplace();
  });
  document.getElementById('explore-location')?.addEventListener('change', (e) => {
    state.exploreFilter.location = e.target.value;
    saveState();
    renderExploreMarketplace();
  });
  document.getElementById('explore-sort')?.addEventListener('change', (e) => {
    state.exploreFilter.sort = e.target.value;
    saveState();
    renderExploreMarketplace();
  });

  // Pricing plan buttons
  document.querySelectorAll('[data-start-plan]').forEach((b) => {
    b.addEventListener('click', () => {
      showToast(`Selected ${b.getAttribute('data-start-plan')} prototype plan. Launching onboarding...`);
      switchView('onboarding');
    });
  });

  // Footer info modals
  document.querySelectorAll('[data-info-modal]').forEach((b) => {
    b.addEventListener('click', () => openInfoModal(b.getAttribute('data-info-modal')));
  });

  // Modal close handlers
  document.getElementById('modal-close-btn')?.addEventListener('click', closeModal);
  document.getElementById('app-modal')?.addEventListener('click', (e) => {
    if (e.target.id === 'app-modal') closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  // Initial Render
  applyLanguage(state.lang);
  renderAgentCards();
  renderAgentWorkbench();
  renderExploreMarketplace();
  initObservers();
  bind3DTilt();

  if (state.activeView !== 'landing') {
    switchView(state.activeView);
  } else {
    refreshIcons();
  }
}

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

