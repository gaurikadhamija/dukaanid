# DukaanID — Updated Ideathon Prototype

## Run the prototype

This is a static HTML/CSS/JavaScript demo. It does not require npm or a backend.

### Option A: VS Code (recommended)
1. Extract the ZIP.
2. Open the `dukaanid-main` folder in VS Code.
3. Install/enable the **Live Server** extension if needed.
4. Right-click `index.html` → **Open with Live Server**.
5. Keep the browser tab open while presenting.

### Option B: Python
1. Extract the ZIP and open a terminal inside the `dukaanid-main` folder.
2. Run `python -m http.server 5500`.
3. Open `http://localhost:5500` in Chrome.

Do not open `index.html` by double-clicking it (`file://`) for the full demo. The QR deep-link is designed for a local web-server URL.

## Suggested ideathon walkthrough (4 minutes)

1. **Landing page:** Explain DukaanID's purpose and use Explore Businesses.
2. **Customer journey:** Open Meena's Homemade Kitchen (or another listing), choose a service, select a date/time and submit a booking with a name and phone number.
3. **Worker dashboard:** Select **For Businesses** or use the demo login, then open **Bookings**. The new booking appears as Pending.
4. **Agent workflow:** Accept the booking, then mark it Completed. Completing it adds a linked Pending invoice and writes an event to the AI Agent Activity Centre on the Overview tab.
5. **Payments:** Open Payments & Invoices, mark the linked invoice Paid. The Overview revenue and Credit Passport's tracked paid-invoice total update from the demo records.
6. **Reputation:** Open Reputation to show the worker's reputation wallet and existing sample reviews.
7. **Credit passport:** Open Credit Readiness → Generate My Credit Passport. Try sharing without consent (it is blocked), then tick consent and share. Download Summary to save a text report.
8. **QR storefront:** Open a storefront and use Share Store. The QR image resolves to the local app's `?store=<id>` route. QR image generation requires an internet connection; run the app through Live Server/Python HTTP server rather than `file://`.

## What is now connected in the demo

- Booking submission adds a pending booking to the worker dashboard.
- Accept/reject/complete booking actions update the booking record.
- Completing a booking creates a linked pending invoice (without duplicating it if clicked again).
- Marking an invoice Paid updates tracked revenue and the credit-passport paid-invoice summary.
- Important booking, payment and credit-passport actions are recorded in the AI Agent Activity Centre.
- QR codes are generated as actual QR images and open the selected storefront route when the app is hosted locally or deployed.
- WhatsApp reminder actions show an editable-style message preview and explicitly do not claim a message was sent.
- Credit passport sharing requires explicit consent and the downloadable report uses current demo records.
- Demo state persists in the browser's LocalStorage. Use Settings → Reset Demo Data to restore the starting data.

## Important demo limitations (be transparent with judges)

This remains a **frontend-only ideathon prototype**. It uses LocalStorage and sample data. It does not have production authentication, a server/database, real AI model/agent API calls, actual UPI collection, WhatsApp Business API delivery, lender/Account Aggregator integration, ONDC integration, or live identity verification. The AI Agent Activity Centre is an auditable simulation of proposed agent actions. QR image generation calls an external QR image service and therefore needs internet access.

For the pitch, describe these as prototype simulations / planned integrations, not live production integrations.
